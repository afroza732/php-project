<?php
 $pages='checkout_pages';
 include './index.php';

