<?php
ob_start();
require './classes/application.php';
$obj_app = new Application();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>
            <?php
            if (isset($pages)) {
                if ($pages == 'Catagory') {
                    echo $pages;
                } elseif ($pages == 'Blog') {
                    echo $pages;
                } elseif ($pages == '404') {
                    echo $pages;
                }
            } else {
                echo 'Home';
            }
            ?>
        </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Gifty Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="asset/front_end/css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- Custom Theme files -->
        <link href="asset/front_end/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="asset/front_end/css/jquery.countdown.css" />
        <!-- Custom Theme files -->
        <!--webfont-->
        <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
        <script type="text/javascript" src="asset/front_end/js/jquery-1.11.1.min.js"></script>
        <!-- dropdown -->
        <script src="asset/front_end/js/jquery.easydropdown.js"></script>
        <!-- start menu -->
        <link href="asset/front_end/css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="asset/front_end/js/megamenu.js"></script>
        <script>$(document).ready(function () {
                $(".megamenu").megamenu();
            });
        </script>
        <script src="asset/front_end/js/responsiveslides.min.js"></script>
        <script>
            $(function () {
                $("#slider").responsiveSlides({
                    auto: true,
                    nav: false,
                    speed: 500,
                    namespace: "callbacks",
                    pager: true,
                });
            });
        </script>
        <link rel="stylesheet" href="asset/front_end/css/etalage.css">
        <script src="asset/front_end/js/jquery.etalage.min.js"></script>
        <script>
            jQuery(document).ready(function ($) {

                $('#etalage').etalage({
                    thumb_image_width: 300,
                    thumb_image_height: 400,
                    source_image_width: 900,
                    source_image_height: 1200,
                    show_hint: true,
                    click_callback: function (image_anchor, instance_id) {
                        alert('Callback example:\nYou clicked on an image with the anchor: "' + image_anchor + '"\n(in Etalage instance: "' + instance_id + '")');
                    }
                });

            });
        </script>
        <script src="asset/front_end/js/jquery.countdown.js"></script>
        <script src="asset/front_end/js/script.js"></script>
    </head>
    <body>
        <?php include 'includes/header_top.php'; ?>
        <?php include 'includes/header_bottom.php'; ?>

        <?php include './includes/menu.php'; ?>
        <?php
        if (isset($pages)) {
            if ($pages == 'Catagory') {
                include './pages/catagory_content.php';
            } elseif ($pages == 'Blog') {
                include './pages/blog_content.php';
            } elseif ($pages == '404') {
                include './pages/404_content.php';
            } elseif ($pages == 'product_details') {
                include './pages/product_details_content.php';
            } elseif ($pages == 'cart_pages') {
                include './pages/cart_pages_content.php';
            } elseif ($pages == 'checkout_pages') {
                include './pages/checkout_pages_content.php';
            } 
            elseif ($pages == 'shipping_page') {
                include './pages/shipping_page_content.php';
            }
            elseif ($pages == 'payment_page') {
                include './pages/payment_page_content.php';
            }
            elseif ($pages == 'customer_home_page') {
                include './pages/customer_home_page_content.php';
            }
        } else {
            include './pages/home_page.php';
        }
        ?>
        <?php include './includes/fotter.php'; ?>

        <link href="asset/front_end/css/flexslider.css" rel='stylesheet' type='text/css' />
        <script defer src="asset/front_end/js/jquery.flexslider.js"></script>
        <script type="text/javascript">
            $(function () {
                SyntaxHighlighter.all();
            });
            $(window).load(function () {
                $('.flexslider').flexslider({
                    animation: "slide",
                    start: function (slider) {
                        $('body').removeClass('loading');
                    }
                });
            });
        </script>
    </body>
</html>		