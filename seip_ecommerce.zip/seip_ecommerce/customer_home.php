<?php
$pages='customer_home_page';
include './index.php';

