<?php

session_start();

class Application {

    public function __construct() {
        $hostname = 'localhost';
        $username = 'root';
        $password = '';
        $db_name = 'db_seip_ecommerce';

        $conn = mysqli_connect($hostname, $username, $password);
        if ($conn) {
            $db_select = mysqli_select_db($conn, $db_name);
            if ($db_select) {
                return $conn;
            } else {
                die('connection error' . mysqli_error($db_select));
            }
        } else {
            die('database connection error' . mysqli_error($conn));
        }
    }

    public function select_all_published_caategory_info() {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_category WHERE publication_status=1 AND deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_all_published_product() {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_product WHERE publication_status=1 AND deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function category_page_show($category_id) {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_product WHERE deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function product_details_info($product_id) {
        $conn = $this->__construct();
        $sql = "SELECT p.*,c.category_name,m.menufeachures_name "
                . "FROM tbl_product as p,tbl_category as c,"
                . "tbl_menufeatures as m WHERE "
                . "p.category_id=c.category_id AND"
                . " p.menufeachures_id = m.menufeachures_id "
                . "AND P.product_id='$product_id'";
        if (mysqli_query($conn, $sql)) {
            $product_details = mysqli_query($conn, $sql);
            return $product_details;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function product_category_info_by_id($category_id) {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_product WHERE category_id='$category_id' AND publication_status=1 AND deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $result = mysqli_query($conn, $sql);
            return $result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function product_save_cart_info($data) {
        $conn = $this->__construct();
        $product_id = $data['product_id'];
        $sql = "SELECT * FROM tbl_product WHERE product_id='$product_id'";
        $query_result = mysqli_query($conn, $sql);
        $product_info = mysqli_fetch_assoc($query_result);
        $product_quantity = $product_info['product_quantity'];
        $cart_product_quantity = $data['product_quantity'];
        if ($cart_product_quantity > $product_quantity) {
            echo 'You have to order equal or less then' . ' ' . $product_quantity;
        } else if ($cart_product_quantity < 1) {
            echo 'You have to order is greater then 0';
        } else {
            $session_id = session_id();
            $sql = "INSERT INTO tbl_temp_cart(product_id,session_id,product_name,image,product_price,product_quantity)VALUES('$product_id','$session_id','$product_info[product_name]','$product_info[image]','$product_info[product_price]','$data[product_quantity]')";
            mysqli_query($conn, $sql);
            header('Location: cart.php');
        }
    }

    public function select_cart_product_info_by_session_id() {
        $conn = $this->__construct();
        $session_id = session_id();
        $sql = "SELECT * FROM tbl_temp_cart WHERE session_id='$session_id'";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function update_cart_info($data) {
        $conn = $this->__construct();
        $session_id = session_id();
        $sql = "UPDATE tbl_temp_cart SET product_quantity='$data[product_quantity]' WHERE session_id='$session_id' AND product_id='$data[product_id]'";
        if (mysqli_query($conn, $sql)) {
            $message = 'cart info update succssfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function delete_cart_info($product_id) {
        $conn = $this->__construct();
        $sql = "DELETE FROM tbl_temp_cart WHERE product_id='$product_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'cart info update succssfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function registration_save_info($data) {
        $conn = $this->__construct();
        $password = md5($data['password']);
        $sql = "INSERT INTO tbl_registration(first_name,last_name,email_address,password,address,phone_number,city,country)VALUES('$data[first_name]','$data[last_name]','$data[email_address]','$password','$data[address]','$data[phone_number]','$data[city]','$data[country]')";
        if (mysqli_query($conn, $sql)) {
            $customer_id = mysqli_insert_id($conn);
            $_SESSION['customer_id'] = $customer_id;
            $_SESSION['customer_name'] = $data['first_name'] . ' ' . $data['last_name'];
            header('Location: Shipping.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function shipping_save_info($data) {
        $conn = $this->__construct();
        $sql = "INSERT INTO tbl_shipping(full_name,email_address,address,phone_number,city,country)VALUES('$data[full_name]','$data[email_address]','$data[address]','$data[phone_number]','$data[city]','$data[country]')";
        if (mysqli_query($conn, $sql)) {
            $shipping_id = mysqli_insert_id($conn);
            $_SESSION['shipping_id'] = $shipping_id;
            header('Location: Payment.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function order_save_info($data) {
        $conn = $this->__construct();
        $payment_type = $data['payment_type'];
        if ($payment_type == 'cash_on_delivery') {
            $sql = "INSERT INTO tbl_order(customer_id,shipping_id,order_total)VALUES('$_SESSION[customer_id]','$_SESSION[shipping_id]','$_SESSION[order_total]')";
            if (mysqli_query($conn, $sql)) {
                $order_id = mysqli_insert_id($conn);
                $_SESSION['order_id'] = $order_id;
                $sql = "INSERT INTO tbl_payment(order_id,payment_type)VALUES('$_SESSION[order_id]','$payment_type')";
                if (mysqli_query($conn, $sql)) {
                    $session_id = session_id();
                    $sql = "SELECT * FROM tbl_temp_cart WHERE session_id='$session_id'";
                    $query_result = mysqli_query($conn, $sql);
                    while ($row = mysqli_fetch_assoc($query_result)) {
                        $sql = "INSERT INTO tbl_details_order(order_id,product_id,product_name,product_price,product_quantity)VALUES('$_SESSION[order_id]','$row[product_id]','$row[product_name]','$row[product_price]','$row[product_quantity]')";

                        mysqli_query($conn, $sql);
                    }
                    $sql = "DELETE FROM tbl_temp_cart WHERE session_id='$session_id'";
                    mysqli_query($conn, $sql);
                    header('Location: customer_home.php');
                } else {
                    die('query problem' . mysqli_error($conn));
                }
            } else {
                die('query problem' . mysqli_error($conn));
            }
        } elseif ($payment_type == 'bkash') {
            
        }
    }
public function customer_logout_info(){
    unset($_SESSION['customer_id']);
    unset($_SESSION['customer_name']);
    unset($_SESSION['shipping_id']);
    unset($_SESSION['order_id']);
    header('Location: index.php');
}
}


