<?php

class Admin {

    public function __construct() {
        $hostname = 'localhost';
        $username = 'root';
        $password = '';
        $db_name = 'db_seip_ecommerce';

        $conn = mysqli_connect($hostname, $username, $password);
        if ($conn) {
            $db_select = mysqli_select_db($conn, $db_name);
            if ($db_select) {
                return $conn;
            } else {
                die('connection error' . mysqli_error($db_select));
            }
        } else {
            die('database connection error' . mysqli_error($conn));
        }
    }

    public function admin_login_check($data) {
        $conn = $this->__construct();
        $password = md5($data['password']);
        $sql = "SELECT * FROM tbl_admin WHERE email_address='$data[email_address]' AND password ='$password' AND deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            $admin_info = mysqli_fetch_assoc($query_result);
            if ($admin_info) {
                session_start();
                $_SESSION['admin_id'] = $admin_info['admin_id'];
                $_SESSION['admin_name'] = $admin_info['admin_name'];
                header('Location: admin_master.php');
            } else {
                $message = 'Please use valid email_address and password';
                return $message;
            }
        } else {
            die('Query problem' . mysqli_error($conn));
        }
    }

//////////////////////// login check ending//////////////////////////////////////


    public function category_save_info($data) {
        $conn = $this->__construct();
        $sql = "INSERT INTO tbl_category(category_name,category_description,publication_status)VALUES('$data[category_name]','$data[category_description]','$data[publication_status]')";
        if (mysqli_query($conn, $sql)) {
            $message = 'data inserted successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function category_view_info() {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_category WHERE deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function category_published_info($category_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_category SET publication_status=1 WHERE category_id='$category_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'category info published successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function category_unpublished_info($category_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_category SET publication_status=0 WHERE category_id='$category_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'category info unpublished successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function category_delete_info($category_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_category SET deletion_status=0 WHERE category_id='$category_id'";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "category info delete successfully!";
            header('Location: manage_category.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_category_info_by_id($category_id) {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_category WHERE category_id='$category_id'";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function category_update_info($data) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_category SET category_name ='$data[category_name]',category_description ='$data[category_description]', publication_status='$data[publication_status]' WHERE category_id='$data[category_id]'";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "category info update successfully!";
            header('Location: manage_category.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_all_published_caategory_info() {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_category WHERE publication_status=1 AND deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

/////////////////////// category ending//////////////////////////////////////
    public function menufeature_save_info($data) {
        $conn = $this->__construct();
        $sql = "INSERT INTO tbl_menufeatures(menufeachures_name,menufeachures_description,publication_status)VALUES('$data[menufeachures_name]','$data[menufeachures_description]','$data[publication_status]')";
        if (mysqli_query($conn, $sql)) {
            $message = 'data inserted successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function menufeature_view_info() {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_menufeatures WHERE deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function menufeatures_unpublished_info($menufeachures_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_menufeatures SET publication_status=0 WHERE menufeachures_id='$menufeachures_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'MENUFETURES info unpublished successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function menufeatures_published_info($menufeachures_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_menufeatures SET publication_status=1 WHERE menufeachures_id='$menufeachures_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'MENUFETURES info published successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_menufeture_info_by_id($menufeachures_id) {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_menufeatures WHERE menufeachures_id='$menufeachures_id'";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function menufeture_update_info($data) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_menufeatures SET menufeachures_name ='$data[menufeachures_name]',menufeachures_description ='$data[menufeachures_description]', publication_status='$data[publication_status]' WHERE menufeachures_id='$data[menufeachures_id]'";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "manage_menufeachers info update successfully!";
            header('Location: manage_menufeachers.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_all_published_menufeture_info() {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_menufeatures WHERE publication_status=1 AND deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $result = mysqli_query($conn, $sql);
            return $result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function menufeatures_delete_info($menufeachures_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_menufeatures SET deletion_status=0 WHERE menufeachures_id='$menufeachures_id'";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "category info delete successfully!";
            header('Location: manage_menufeachers.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

/////////////////////// menufeature ending//////////////////////////////////////

    public function save_info_add_product($data) {
        $conn = $this->__construct();
        $directory = '../asset/admin_assets/product_image/';
        $target_file = $directory . $_FILES['image']['name'];
        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
        $file_size = $_FILES['image']['size'];
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check) {
            if (file_exists($target_file)) {
                echo 'Your upload file is alrady exists!.please try again';
            } else {
                if ($file_type != 'jpg' && $file_type != 'png') {
                    echo 'our upload file is not valid.please try again';
                } else {
                    if ($file_size > 520000) {
                        echo 'Your file size is too large.please try again later';
                    } else {
                        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
                        $sql = "INSERT INTO tbl_product(product_name,category_id,menufeachures_id,product_price,product_quantity,product_sku,product_short_description,product_long_description,image,publication_status)VALUES('$data[product_name]','$data[category_id]','$data[menufeachures_id]','$data[product_price]','$data[product_quantity]','$data[product_sku]','$data[product_short_description]','$data[product_long_description]','$target_file','$data[publication_status]')";
                        if (mysqli_query($conn, $sql)) {
                            $message = 'product info save successfully';
                            return $message;
                        } else {
                            die('query problem' . mysqli_error($conn));
                        }
                    }
                }
            }
        } else {
            echo 'Your upload file is not image.!please try again';
        }
    }

    public function select_all_product_info() {
        $conn = $this->__construct();
        $sql = "SELECT p.*,c.category_name,m.menufeachures_name "
                . "FROM tbl_product as p,tbl_category as c,"
                . "tbl_menufeatures as m WHERE "
                . "p.category_id=c.category_id AND"
                . " p.menufeachures_id = m.menufeachures_id "
                . "AND P.deletion_status=1";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function product_unpublished_info($product_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_product SET publication_status=0 WHERE product_id='$product_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'product info unpublished successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function product_published_info($product_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_product SET publication_status=1 WHERE product_id='$product_id'";
        if (mysqli_query($conn, $sql)) {
            $message = 'MENUFETURES info published successfully';
            return $message;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function product_delete_info($product_id) {
        $conn = $this->__construct();
        $sql = "UPDATE tbl_product SET deletion_status=0 WHERE product_id='$product_id'";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "category info delete successfully!";
            header('Location: manage_menufeachers.php');
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_product_info_by_id($product_id) {
        $conn = $this->__construct();
        $sql = "SELECT p.*,c.category_name,m.menufeachures_name "
                . "FROM tbl_product as p,tbl_category as c,"
                . "tbl_menufeatures as m WHERE "
                . "p.category_id=c.category_id AND"
                . " p.menufeachures_id = m.menufeachures_id "
                . "AND P.product_id='$product_id'";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function update_info_product($data) {
        $conn = $this->__construct();
        $directory = '../asset/admin_assets/product_image/';
        $target_file = $directory . $_FILES['image']['name'];
        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
        $file_size = $_FILES['image']['size'];
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check) {
            if (file_exists($target_file)) {
                echo 'Your upload file is alrady exists!.please try again';
            } else {
                if ($file_type != 'jpg' && $file_type != 'png') {
                    echo 'our upload file is not valid.please try again';
                } else {
                    if ($file_size > 520000) {
                        echo 'Your file size is too large.please try again later';
                    } else {
                        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
                        $sql = "UPDATE tbl_product SET product_name='$data[product_name]',category_id='$data[category_id]',menufeachures_id='$data[menufeachures_id]',product_price='$data[product_price]',product_quantity='$data[product_quantity]',product_sku='$data[product_sku]',product_short_description='$data[product_short_description]',product_long_description='$data[product_long_description]',image='$target_file',publication_status='$data[publication_status]'";
                        if (mysqli_query($conn, $sql)) {
                            session_start();
                            $_SESSION[$message] = 'product info update successfully';
                            header('Location: manage_product.php');
                        } else {
                            die('query problem' . mysqli_error($conn));
                        }
                    }
                }
            }
        } else {
            echo 'Your upload file is not image.!please try again';
        }
    }

    public function order_view_info() {
        $conn = $this->__construct();
        $sql = "SELECT o.order_id,o.customer_id,o.order_total,o.order_status,c.first_name,c.last_name,p.payment_type,p.payment_status FROM tbl_order as o,tbl_registration as c,tbl_payment as p WHERE o.customer_id=c.customer_id AND o.order_id=p.order_id";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_order_info_by_id($order_id) {
        $conn = $this->__construct();
        $sql = "SELECT o.order_id,o.customer_id,c.* FROM tbl_order as o,tbl_registration as c WHERE o.customer_id=c.customer_id AND o.order_id='$order_id'";
        if (mysqli_query($conn, $sql)) {
            $order_query_result = mysqli_query($conn, $sql);
            return $order_query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_shipping_info_by_id($order_id) {
        $conn = $this->__construct();
        $sql = "SELECT o.order_id,o.shipping_id,s.* FROM tbl_order as o,tbl_shipping as s WHERE o.shipping_id=s.shipping_id AND o.order_id='$order_id'";
        if (mysqli_query($conn, $sql)) {
            $shipping_query_result = mysqli_query($conn, $sql);
            return $shipping_query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

    public function select_product_details_info_by_id($order_id) {
        $conn = $this->__construct();
        $sql = "SELECT * FROM tbl_details_order WHERE order_id='$order_id'";
        if (mysqli_query($conn, $sql)) {
            $query_result = mysqli_query($conn, $sql);
            return $query_result;
        } else {
            die('query problem' . mysqli_error($conn));
        }
    }

/////////////////////// category ending//////////////////////////////////////

    public function admin_logout() {
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        header('Location: index.php');
    }

}
