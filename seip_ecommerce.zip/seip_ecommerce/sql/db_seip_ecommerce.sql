-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2018 at 05:55 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_seip_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(5) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `email_address` varchar(200) NOT NULL,
  `password` varchar(300) NOT NULL,
  `access_level` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `email_address`, `password`, `access_level`, `deletion_status`) VALUES
(1, 'afroza', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(10) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` text NOT NULL,
  `publication_status` tinyint(2) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`, `publication_status`, `deletion_status`) VALUES
(3, 'dress', '<b>i need this dress</b>', 1, 0),
(4, 'electronic', 'well', 0, 0),
(5, 'product', 'good', 1, 0),
(6, 'Mobile', 'good product<br>', 1, 1),
(7, 'afroza', 'well', 1, 0),
(8, 'Television', 'Beautifull product<br>', 1, 1),
(9, 'Samsung', 'good product<br>', 1, 1),
(10, 'Note-3', 'Well product<br>', 1, 1),
(11, 'Note-7', 'well<br>', 1, 1),
(12, 'Books', 'well book<br>', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_details_order`
--

CREATE TABLE `tbl_details_order` (
  `order_details_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_details_order`
--

INSERT INTO `tbl_details_order` (`order_details_id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_quantity`) VALUES
(1, 1, 24, 'New product', 200000, 3),
(2, 2, 22, 'note-3', 3000000, 1),
(3, 3, 24, 'New product', 200000, 1),
(4, 4, 22, 'note-3', 3000000, 5),
(5, 5, 22, 'note-3', 3000000, 5),
(6, 5, 22, 'note-3', 3000000, 5),
(7, 6, 24, 'New product', 200000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_image`
--

CREATE TABLE `tbl_image` (
  `image_id` int(10) NOT NULL,
  `image_name` varchar(300) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_image`
--

INSERT INTO `tbl_image` (`image_id`, `image_name`, `image`) VALUES
(1, '', 'asset/image/20170401_171727.jpg'),
(2, 'my image', 'asset/image/20161216_175127.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menufeatures`
--

CREATE TABLE `tbl_menufeatures` (
  `menufeachures_id` int(10) NOT NULL,
  `menufeachures_name` varchar(300) NOT NULL,
  `menufeachures_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_menufeatures`
--

INSERT INTO `tbl_menufeatures` (`menufeachures_id`, `menufeachures_name`, `menufeachures_description`, `publication_status`, `deletion_status`) VALUES
(1, '', 'tv234', 1, 0),
(2, 'Mobile', 'well product well product<br>', 1, 1),
(3, 'Television', 'good product good product<br>', 1, 1),
(4, 'Electronic', 'Electronic product is a good product<br>', 1, 1),
(5, 'Freeze', 'Freeze is good<br>', 1, 1),
(6, 'Electronic', 'Electronic<br>', 1, 1),
(7, 'Mobile', 'Mobile is good product recent<br>', 1, 1),
(8, 'Samsung', 'MobileMobileMobileMobileMobileMobileMobile', 1, 1),
(9, '9', 'gggggggggg', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `order_total` float(10,2) NOT NULL,
  `order_status` varchar(10) NOT NULL DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `order_total`, `order_status`, `order_date`) VALUES
(1, 12, 2, 0.00, 'pending', '2018-10-30 19:12:06'),
(2, 13, 3, 3450000.00, 'pending', '2018-10-30 19:17:13'),
(3, 13, 4, 230000.00, 'pending', '2018-10-30 19:44:17'),
(4, 13, 5, 17250000.00, 'pending', '2018-10-30 20:00:37'),
(5, 14, 6, 34500000.00, 'pending', '2018-11-01 15:34:03'),
(6, 15, 7, 460000.00, 'pending', '2018-11-01 17:23:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `payment_status` varchar(100) NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `order_id`, `payment_type`, `payment_status`, `payment_date`) VALUES
(1, 1, 'cash_on_delivery', 'pending', '2018-10-30 19:12:06'),
(2, 2, 'cash_on_delivery', 'pending', '2018-10-30 19:17:13'),
(3, 3, 'cash_on_delivery', 'pending', '2018-10-30 19:44:17'),
(4, 4, 'cash_on_delivery', 'pending', '2018-10-30 20:00:37'),
(5, 5, 'cash_on_delivery', 'pending', '2018-11-01 15:34:04'),
(6, 6, 'cash_on_delivery', 'pending', '2018-11-01 17:23:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(10) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category_id` int(3) NOT NULL,
  `menufeachures_id` int(3) NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_quantity` int(5) NOT NULL,
  `product_sku` int(5) NOT NULL,
  `product_short_description` text NOT NULL,
  `product_long_description` text NOT NULL,
  `image` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `category_id`, `menufeachures_id`, `product_price`, `product_quantity`, `product_sku`, `product_short_description`, `product_long_description`, `image`, `publication_status`, `deletion_status`) VALUES
(15, 'Nokia', 6, 6, 10000.00, 200, 20, '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">well product</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"></span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"><br></span>', '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolo</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">re magna aliquam erat</span>', '../asset/admin_assets/product_image/5.jpg', 1, 1),
(16, 'Nokia', 6, 6, 10000.00, 200, 20, '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">well product</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"></span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"><br></span>', '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolo</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">re magna aliquam erat</span>', '../asset/admin_assets/product_image/5.jpg', 1, 0),
(17, 'Nokia', 6, 6, 10000.00, 200, 20, '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">well product</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"></span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"><br></span>', '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolo</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">re magna aliquam erat</span>', '../asset/admin_assets/product_image/5.jpg', 1, 0),
(19, 'Nokia', 6, 6, 10000.00, 200, 20, '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">well product</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"></span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"><br></span>', '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolo</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">re magna aliquam erat</span>', '../asset/admin_assets/product_image/5.jpg', 1, 0),
(20, 'Nokia', 6, 6, 10000.00, 200, 20, '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">well product</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"></span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\"><br></span>', '<span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolo</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat</span><span style=\"color: rgb(142, 117, 88); font-family: Raleway, sans-serif; font-size: 13.6px; background-color: rgb(255, 255, 255);\">re magna aliquam erat</span>', '../asset/admin_assets/product_image/5.jpg', 1, 0),
(21, 'Samsung', 6, 6, 20000.00, 200, 20, 'well product<br>', 'good product<br>', '../asset/admin_assets/product_image/6.jpg', 1, 0),
(22, 'note-3', 6, 6, 3000000.00, 300, 20, 'good product<br>', 'good product<br>', '../asset/admin_assets/product_image/7.jpg', 1, 1),
(23, 'Samsung', 8, 6, 1397259.00, 2002, 30, 'well product<br>', 'well product<br>', '../asset/admin_assets/product_image/tcl.jpg', 1, 1),
(24, 'New product', 8, 3, 200000.00, 10, 10, 'well product well produc<br>', 'well product well producwell product well producwell product well producwell product <br>', '../asset/admin_assets/product_image/8.jpg', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product1`
--

CREATE TABLE `tbl_product1` (
  `product_id` int(10) NOT NULL,
  `category_id` int(3) NOT NULL,
  `menufeachures_id` int(3) NOT NULL,
  `product_price` int(5) NOT NULL,
  `product_quantity` int(5) NOT NULL,
  `product_sku` varchar(200) NOT NULL,
  `product_short_description` text NOT NULL,
  `product_long_description` text NOT NULL,
  `image` varchar(10) NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE `tbl_registration` (
  `customer_id` int(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email_address` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `phone_number` int(5) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`customer_id`, `first_name`, `last_name`, `email_address`, `password`, `address`, `phone_number`, `city`, `country`) VALUES
(1, '', '', '', '', '', 0, '', 'Bangladesh'),
(2, 'afroza', 'nisha', 'admin@gmail.com', 'admin', 'Tangail', 1786942732, 'Dhaka', 'Bangladesh'),
(3, 'nisha', 'shikder', 'nisha@gmail.com', 'nisha', 'Tangail', 1689353867, 'Dhaka', 'United States'),
(4, 'admin', 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'Austrolia', 2147483647, 'Austrolia', 'Canada'),
(5, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', '---Select Your Country---'),
(6, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', ''),
(7, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', '---Select Your Country---'),
(8, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', ''),
(9, '', '', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '', 0, '', ''),
(10, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', '---Select Your Country---'),
(11, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', ''),
(12, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, '', '---Select Your Country---'),
(13, 'afroza', 'nisha', 'nisha@gmail.com', 'a9f56b7ece2113c9c4a1214a19ede99c', 'Tangail', 2147483647, 'Dhaka', 'Bangladesh'),
(14, 'nisha', 'afroza', 'nishaafroza@gmail.com', 'a09417501e2cd205ade459841fb4a9d9', 'Tangail', 3546567, 'Dhaka', 'Bangladesh'),
(15, 'meherun', 'lira', 'meherunlira@gmail.com', '7b13a7039b72505a03fcc53baf915954', 'Tangail', 1719815612, 'Dhaka', 'Bangladesh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `shipping_id` int(100) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `phone_number` varchar(40) NOT NULL,
  `city` varchar(200) NOT NULL,
  `country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `full_name`, `email_address`, `address`, `phone_number`, `city`, `country`) VALUES
(1, 'afroza nisha', 'afrozanisha@gmail.com', 'Dhaka', '01786942732', 'Tangail', 'Bangladesh'),
(2, '', '', '', '', '', '---Select Your Country---'),
(3, 'afroza nisha', 'nisha@gmail.com', 'Tangail', '2546666666', 'Dhaka', 'Bangladesh'),
(4, '', '', '', '', '', '---Select Your Country---'),
(5, 'afroza nisha', 'afrozanisha@gmail.com', 'tangail', '8798378', 'Dhaka', 'Bangladesh'),
(6, 'nishaafroza', 'nishaafroza@gmail.com', 'Tangail', '43860985', 'Dhaka', 'India'),
(7, 'lira meherun', 'lirameherun@gmail.com', 'Tangail', '01719815612', 'Dhaka', 'Bangladesh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_temp_cart`
--

CREATE TABLE `tbl_temp_cart` (
  `temp_cart_id` int(5) NOT NULL,
  `product_id` int(5) NOT NULL,
  `session_id` int(5) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_temp_cart`
--

INSERT INTO `tbl_temp_cart` (`temp_cart_id`, `product_id`, `session_id`, `product_name`, `image`, `product_price`, `product_quantity`) VALUES
(12, 24, 96612, 'New product', '../asset/admin_assets/product_image/8.jpg', 200000.00, 1),
(13, 24, 96612, 'New product', '../asset/admin_assets/product_image/8.jpg', 200000.00, 3),
(14, 24, 96612, 'New product', '../asset/admin_assets/product_image/8.jpg', 200000.00, 3),
(15, 24, 96612, 'New product', '../asset/admin_assets/product_image/8.jpg', 200000.00, 1),
(16, 22, 96612, 'note-3', '../asset/admin_assets/product_image/7.jpg', 3000000.00, 1),
(17, 23, 96612, 'Samsung', '../asset/admin_assets/product_image/tcl.jpg', 1397259.00, 1),
(18, 24, 96612, 'New product', '../asset/admin_assets/product_image/8.jpg', 200000.00, 4),
(20, 23, 0, 'Samsung', '../asset/admin_assets/product_image/tcl.jpg', 1397259.00, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_details_order`
--
ALTER TABLE `tbl_details_order`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `tbl_image`
--
ALTER TABLE `tbl_image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `tbl_menufeatures`
--
ALTER TABLE `tbl_menufeatures`
  ADD PRIMARY KEY (`menufeachures_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_product1`
--
ALTER TABLE `tbl_product1`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `tbl_temp_cart`
--
ALTER TABLE `tbl_temp_cart`
  ADD PRIMARY KEY (`temp_cart_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_details_order`
--
ALTER TABLE `tbl_details_order`
  MODIFY `order_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_image`
--
ALTER TABLE `tbl_image`
  MODIFY `image_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_menufeatures`
--
ALTER TABLE `tbl_menufeatures`
  MODIFY `menufeachures_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_product1`
--
ALTER TABLE `tbl_product1`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `customer_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `shipping_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_temp_cart`
--
ALTER TABLE `tbl_temp_cart`
  MODIFY `temp_cart_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
