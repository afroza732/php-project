<?php
    $pages='Catagory';
    include './index.php';
?>