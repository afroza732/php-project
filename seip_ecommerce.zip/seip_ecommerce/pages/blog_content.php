<?php
    echo 'Hai';
?>

