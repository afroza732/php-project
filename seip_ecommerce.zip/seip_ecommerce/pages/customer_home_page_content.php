<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr/>
            <hr/>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well">
                <h3>Thanks <?php echo  $_SESSION['customer_name'];?> For your order. We will contact with you soon.</h3>
            </div>
        </div>
    </div>
</div>