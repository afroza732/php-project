<?php
$product_id = $_GET['product_id'];
$product_details = $obj_app->product_details_info($product_id);
$product_details_info = mysqli_fetch_assoc($product_details);
$category_id=$product_details_info['category_id'];
$result = $obj_app->product_category_info_by_id($category_id);

if(isset($_POST['cart_btn'])){
$obj_app->product_save_cart_info($_POST);

}
?>
<div class="men">
    <div class="container">
        <div class="single_top">
            <div class="col-md-9 single_right">
                <div class="grid images_3_of_2">
                    <ul id="etalage">
                        <li>
                            <a href="optionallink.html">
                                <img class="etalage_thumb_image"width="200" height="200" src="asset/<?php echo $product_details_info['image']; ?>" class="img-responsive" />
                                <img class="etalage_source_image" src="admin/<?php echo $product_details_info['image']; ?>" class="img-responsive" title="" />
                            </a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>		
                </div> 
                <div class="desc1 span_3_of_2">
                    <h1><b>Product Name:</b> <?php echo $product_details_info['product_name']; ?></h1>
                    <h1><b>Category Name:</b> <?php echo $product_details_info['category_name']; ?></h1>
                    <h1><b>Menufeture Name:</b> <?php echo $product_details_info['menufeachures_name']; ?></h1>
                    <h1><b>Product Price:</b> BDT.<?php echo $product_details_info['product_price']; ?></h1>
                    <h1><b>Product Stock amount:</b> <?php echo $product_details_info['product_quantity']; ?></h1>

                    <div class="btn_form">
                        <form action="" method="post">
                            <input type="number" name="product_quantity" value="1" title="">
                            <input type="hidden" name="product_id" value="<?php echo $product_details_info['product_id'];?>" title="">
                            <input type="submit" name="cart_btn" value="add to cart" title="">
                        </form>
                    </div>
                </div>
                <div class="clearfix"></div>	
            </div>
            <div class="col-md-3">
                <!-- FlexSlider -->
                <section class="slider_flex">
                    <div class="flexslider">
                        <ul class="slides">
                            <li><img src="asset/front_end/images/pic4.jpg" class="img-responsive" alt=""/></li>
                            <li><img src="asset/front_end/images/pic7.jpg" class="img-responsive" alt=""/></li>
                            <li><img src="asset/front_end/images/pic6.jpg" class="img-responsive" alt=""/></li>
                            <li><img src="asset/front_end/images/pic5.jpg" class="img-responsive" alt=""/></li>
                        </ul>
                    </div>
                </section>
                <!-- FlexSlider -->
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="toogle">
            <h2>Product Details</h2>
            <p class="m_text2"><?php echo $product_details_info['product_short_description'] ;?></p>
        </div>
        <div class="toogle">
            <h2>More Information</h2>
            <p class="m_text2"><?php echo $product_details_info['product_long_description']; ?></p>
        </div>
        <h4 class="head_single">Related Products</h4>
        <?php while ($product_info= mysqli_fetch_assoc($result)){?>
        <div class="span_3">
            <div class="col-sm-3 grid_1">
                <a href="product_details.php?category_id=<?php echo $product_info['category_id'];?>">
                    <img src="asset/<?php echo $product_info['image'];?>" class="img-responsive" alt=""/>
                    <h3><?php echo $product_info['product_name'];?></h3>
                    <p>Duis autem vel eum iriure</p>
                    <h4>Rs.<?php echo $product_info['product_price'];?></h4>
                </a>  
            </div> 
              <?php }?>
            <div class="clearfix"></div>
      
        </div>
    </div>
</div>
