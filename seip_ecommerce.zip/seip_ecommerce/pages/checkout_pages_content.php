<?php
if(isset($_POST['reg_btn'])){
   $obj_app->registration_save_info($_POST);
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr/>
            <hr/>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well">
                <h4 class="text-center text_resize">You have to login to complete your valuable order.If you are not registered then please registered now!</h4>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="well">
                <h3 class="text-center text-success">Registration Form</h3>
                <form class="form-horizontal" action="" method="post">
                    <div class="form-group">
                        <label class="control-label col-md-4">First Name</label>
                        <div class="col-md-8">
                            <input type="text" name="first_name" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Last Name</label>
                        <div class="col-md-8">
                            <input type="text" name="last_name" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Email Address</label>
                        <div class="col-md-8">
                            <input type="email" name="email_address" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Password</label>
                        <div class="col-md-8">
                            <input type="password" name="password" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Address</label>
                        <div class="col-md-8">
                            <textarea name="address" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Phone Number</label>
                        <div class="col-md-8">
                            <input type="number" name="phone_number" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">City</label>
                        <div class="col-md-8">
                            <input type="text" name="city" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Country</label>
                        <div class="col-md-8">
                            <select name="country" class="form-control">
                                <option>---Select Your Country---</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="United States">United States</option>
                                <option value="Canada">Canada</option>
                                <option value="India">India</option>
                                <option value="Japan">Japan</option>
                                <option value="China">China</option>
                                <option value="Franch">France</option>
                                <option value="Nepal">Nepal</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-offset-4 col-md-8">
                            <input type="submit" name="reg_btn" value="registration" class="btn btn-primary btn-block">
                        </div>
                    </div>
                </form>
            </div>
        </div>
         <div class="col-md-6">
            <div class="well">
                <h3 class="text-center text-primary">Login Form</h3>
                <form class="form-horizontal" action="" method="post">
                    <div class="form-group">
                        <label class="control-label col-md-4">Email Address</label>
                        <div class="col-md-8">
                            <input type="email" name="email_address" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Password</label>
                        <div class="col-md-8">
                            <input type="password" name="password" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-offset-4 col-md-8">
                            <input type="submit" name="reg_btn" value="Sign In" class="btn btn-success btn-block">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr/>
            <hr/>
        </div>
    </div>
</div>

