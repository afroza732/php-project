<?php
    $pages='Blog';
    include './index.php';
?>

