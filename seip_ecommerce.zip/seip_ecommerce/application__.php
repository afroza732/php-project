<?php

session_start();

function select_all_published_caategory_info() {
    require './admin/db_connect.php';
    $sql = "SELECT * FROM tbl_category WHERE publication_status=1 AND deletion_status=1";
    if (mysqli_query($conn, $sql)) {
        $query_result = mysqli_query($conn, $sql);
        return $query_result;
    } else {
        die('query problem' . mysqli_error($conn));
    }
}

function select_all_published_product() {
    require './admin/db_connect.php';
    $sql = "SELECT * FROM tbl_product WHERE publication_status=1 AND deletion_status=1";
    if (mysqli_query($conn, $sql)) {
        $query_result = mysqli_query($conn, $sql);
        return $query_result;
    } else {
        die('query problem' . mysqli_error($conn));
    }
}

function category_page_show($category_id) {
    require './admin/db_connect.php';
    $sql = "SELECT * FROM tbl_product WHERE deletion_status=1";
    if (mysqli_query($conn, $sql)) {
        $query_result = mysqli_query($conn, $sql);
        return $query_result;
    } else {
        die('query problem' . mysqli_error($conn));
    }
}

function product_details_info($product_id) {
    require './admin/db_connect.php';
    $sql = "SELECT p.*,c.category_name,m.menufeachures_name "
            . "FROM tbl_product as p,tbl_category as c,"
            . "tbl_menufeatures as m WHERE "
            . "p.category_id=c.category_id AND"
            . " p.menufeachures_id = m.menufeachures_id "
            . "AND P.product_id='$product_id'";
    if (mysqli_query($conn, $sql)) {
        $product_details = mysqli_query($conn, $sql);
        return $product_details;
    } else {
        die('query problem' . mysqli_error($conn));
    }
}

function product_category_info_by_id($category_id) {
    require './admin/db_connect.php';
    $sql = "SELECT * FROM tbl_product WHERE category_id='$category_id' AND publication_status=1 AND deletion_status=1";
    if (mysqli_query($conn, $sql)) {
        $result = mysqli_query($conn, $sql);
        return $result;
    } else {
        die('query problem' . mysqli_error($conn));
    }
}

function product_save_cart_info($data) {
    require './admin/db_connect.php';
    $product_id = $data['product_id'];
    $sql = "SELECT * FROM tbl_product WHERE product_id='$product_id'";
    $query_result = mysqli_query($conn, $sql);
    $product_info = mysqli_fetch_assoc($query_result);
    $product_quantity = $product_info['product_quantity'];
    $cart_product_quantity = $data['product_quantity'];
    if($cart_product_quantity>$product_quantity){
        echo 'You have to order equal or less then'.' '.$product_quantity;
    }else{
     $session_id = session_id();
     $sql = "INSERT INTO tbl_temp_cart(product_id,session_id,product_name,image,product_price,product_quantity)VALUES('$product_id','$session_id','$product_info[product_name]','$product_info[image]','$product_info[product_price]','$data[product_quantity]')";   
     mysqli_query($conn, $sql);
     header('Location: cart.php');
     }  
}
