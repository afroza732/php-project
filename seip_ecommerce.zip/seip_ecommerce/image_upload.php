<?php
require './admin/db_connect.php';

if (isset($_POST['btn'])) {
    $directory = 'asset/image/';
    $target_file = $directory . $_FILES['image']['name'];
    $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
    echo 'File type is: ' . $file_type;
    echo '</br>';
    $file_size = $_FILES['image']['size'];
    echo 'File size is: ' . $file_size;
    echo '</br>';
    $check = getimagesize($_FILES['image']['tmp_name']);

    if ($check) {
        if (file_exists($target_file)) {
            echo 'Your upload file is alrady exists!.please try again';
        } else {
            if ($file_type != 'jpg' && $file_type != 'png') {
                echo 'our upload file is not valid.please try again';
            } else {
                if ($file_size > 520000) {
                    echo 'Your file size is too large.please try again later';
                } else {
                    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
                    $sql = "INSERT INTO tbl_image(image_name,image)VALUES('$_POST[image_name]','$target_file')";
                    mysqli_query($conn, $sql);
                    echo 'image upload and save successfully';
                }
            }
        }
    } else {
        echo 'Your upload file is not image.!please try again';
    }
}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Image upload</title>
    </head>
    <body>
        <form action="" method="post" enctype="multipart/form-data">
            <table>
                <tbody>
                    <tr>
                        <td>Image Name</td>
                        <td><input type="text" name="image_name"></td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td><input type="file" name="image"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="btn" value="submit"></td>
                    </tr>
                </tbody>
            </table> 
        </form>
    </body>
</html>

<br/>
<br/>
<br/>
<?php
$sql = "SELECT * FROM tbl_image";
$query_result = mysqli_query($conn, $sql);
?>
<table>
    <tbody>
        <tr>
            <th>Image Name</th>
            <th>Image</th>
        </tr>
        <?php while ($image_info = mysqli_fetch_assoc($query_result)) { ?>
            <tr>
                <td><?php echo $image_info['image_name']; ?></td>
                <td>
                    <img src="<?php echo $image_info['image']; ?>" alt=""/>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table> 


