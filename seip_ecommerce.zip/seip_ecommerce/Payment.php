<?php
$pages='payment_page';
include './index.php';
