<?php
$pages='shipping_page';
include './index.php';

