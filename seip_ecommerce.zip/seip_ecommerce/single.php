<?php
$pages='single_pages';
include './index.php';