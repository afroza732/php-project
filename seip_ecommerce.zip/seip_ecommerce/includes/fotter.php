<div class="footer">
            <div class="container">
                <img src="asset/front_end/images/pay.png" class="img-responsive" alt=""/>
                <ul class="footer_nav">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Shop</a></li>
                    <li><a href="#">Media</a></li>
                    <li><a href="#">Features</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="contact.html">Contact Us</a></li>
                </ul>
                <p class="copy">Copyright&copy; 2015 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
            </div>
        </div>