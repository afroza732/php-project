<?php
$pages='add_product';
include './admin_master.php';

