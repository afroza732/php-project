<?php
$pages='edit_category';
include './admin_master.php';

