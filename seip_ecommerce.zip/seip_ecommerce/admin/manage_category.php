<?php
    $pages='manage_category';
    include './admin_master.php';
?>
