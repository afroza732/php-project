<?php
$pages='view_order';
include './admin_master.php';