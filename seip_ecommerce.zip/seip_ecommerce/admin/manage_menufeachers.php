<?php
$pages='manage_menufeatures';
include './admin_master.php';

