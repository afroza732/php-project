<?php
$pages='edit_menufetures';
include './admin_master.php';

