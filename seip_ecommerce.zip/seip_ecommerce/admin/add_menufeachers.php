<?php
$pages='add_menufeatures';
include './admin_master.php';

