<?php
$pages='Manage_order';
include './admin_master.php';