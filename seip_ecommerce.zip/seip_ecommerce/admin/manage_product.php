<?php
$pages='manage_product';
include './admin_master.php';

