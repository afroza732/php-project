<?php
$pages='view_product';
include './admin_master.php';

