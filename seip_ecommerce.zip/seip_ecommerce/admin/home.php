<?php
$pages = 'home';
echo 'hello';
?>