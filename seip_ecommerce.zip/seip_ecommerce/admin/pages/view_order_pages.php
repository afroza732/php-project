<?php
$order_id = $_GET['order_id'];
$order_query_result=$obj_admin->select_order_info_by_id($order_id);
$order_info= mysqli_fetch_assoc($order_query_result);

$shipping_query_result=$obj_admin->select_shipping_info_by_id($order_id);
$shipping_info= mysqli_fetch_assoc($shipping_query_result);

$query_result=$obj_admin->select_product_details_info_by_id($order_id);
$product_info= mysqli_fetch_assoc($query_result);
?>

<div class="well">
    <h3 class="text-center text-danger">Customer Info</h3>
</div>
<table class="table table-bordered">
    <tr>
        <th>Customer Name</th>
        <td><?php echo $order_info['first_name'].$order_info['last_name'];?></td>
    </tr>
    <tr>
        <th>Email Address</th>
        <td><?php echo $order_info['email_address'];?></td>
    </tr> 
    <tr>
        <th>Phone Number</th>
        <td><?php echo $order_info['phone_number'];?></td>
    </tr> 
    <tr>
        <th>Address</th>
        <td><?php echo $order_info['address'];?></td>
    </tr> 
    <tr>
        <th>City</th>
        <td><?php echo $order_info['city'];?></td>
    </tr> 
    <tr>
        <th>Country</th>
        <td><?php echo $order_info['country'];?></td>
    </tr>
</table>

<div class="well">
    <h3 class="text-center text-danger">Shipping Info</h3>
</div>
<table class="table table-bordered">
    <tr>
        <th>Full Name</th>
        <td><?php echo $shipping_info['full_name'].$order_info['last_name'];?></td>
    </tr>
    <tr>
        <th>Email Address</th>
        <td><?php echo $shipping_info['email_address'];?></td>
    </tr> 
    <tr>
        <th>Address</th>
        <td><?php echo $shipping_info['address'];?></td>
    </tr> 
    <tr>
        <th>Phone Number</th>
        <td><?php echo $shipping_info['phone_number'];?></td>
    </tr> 
    <tr>
        <th>City</th>
        <td><?php echo $shipping_info['city'];?></td>
    </tr> 
    <tr>
        <th>Country</th>
        <td><?php echo $shipping_info['country'];?></td>
    </tr>
</table>
<div class="well">
    <h3 class="text-center text-danger">Product Info</h3>
</div>
<table class="table table-bordered">
    <tr>
        <th>Product Id</th>
        <th>Product Name</th>
        <th>Customer Price</th>
        <th>Customer Quantity</th>
        <th>Price Total</th>
       
       
    </tr>
    <tr>
        <td><?php echo $product_info['product_id'];?></td>
        <td><?php echo $product_info['product_name'];?></td>
        <td><?php echo $product_info['product_price'];?></td>
        <td><?php echo $product_info['product_quantity'];?></td>
        <td><?php echo $product_info['product_quantity']*$product_info['product_price'];?></td>
       
    </tr>
</table>