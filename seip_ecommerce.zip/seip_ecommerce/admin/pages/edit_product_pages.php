<?php

$product_id=$_GET['product_id'];
$query_result=$obj_admin->select_product_info_by_id($product_id);
$product_info= mysqli_fetch_assoc($query_result);

if(isset($_POST['btn'])){
  $obj_admin->update_info_product($_POST);
}

$query_result =$obj_admin->select_all_published_caategory_info();
$result = $obj_admin->select_all_published_menufeture_info();
?>
<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Form Elements</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">
            <h2>
                <?php
                    if(isset($message)){
                        echo $message;
                        unset($message);
                    }
                ?>
            </h2>
            <form class="form-horizontal" action="" name="edit_product_form" method="post" enctype="multipart/form-data">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="focusedInput">Product Name</label>
                        <div class="controls">
                            <input class="input-xlarge focused" id="focusedInput" name="product_name" type="text" value="<?php echo $product_info['product_name']?>">
                            <input class="input-xlarge focused" id="focusedInput" name="product_id" type="hidden" value="<?php echo $product_info['product_id']?>">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="selectError3" >Category Name</label>
                        <div class="controls">
                            <select id="selectError3" name="category_id">
                                <option>---select category name---</option>
                                <?php while ($category_info = mysqli_fetch_assoc($query_result)) { ?>
                                    <option value="<?php echo $category_info['category_id']; ?>"><?php echo $category_info['category_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="selectError3">Menufeature Name</label>
                        <div class="controls">
                            <select id="selectError3" name="menufeachures_id">
                                <option>---select menufecturer name---</option>
                                <?php while ($menufec_info = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo $menufec_info['menufeachures_id'] ?>"><?php echo $menufec_info['menufeachures_name'] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="focusedInput">Product Price</label>
                        <div class="controls">
                            <input class="input-xlarge focused" id="focusedInput" name="product_price" type="number" value="<?php echo $product_info['product_price']?>">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="focusedInput">Product Quantity</label>
                        <div class="controls">
                            <input class="input-xlarge focused" id="focusedInput" name="product_quantity" type="number" value="<?php echo $product_info['product_quantity']?>">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="focusedInput">Product Sku</label>
                        <div class="controls">
                            <input class="input-xlarge focused" id="focusedInput" name="product_sku" type="text" value="<?php echo $product_info['product_sku']?>">
                        </div>
                    </div>
                    <div class="control-group hidden-phone">
                        <label class="control-label" for="textarea2">Product Short Description</label>
                        <div class="controls">
                            <textarea class="cleditor" name="product_short_description" id="textarea2" rows="3"><?php echo $product_info['product_short_description']?></textarea>
                        </div>
                    </div>
                    <div class="control-group hidden-phone">
                        <label class="control-label" for="textarea2">Product Long Description</label>
                        <div class="controls">
                            <textarea class="cleditor" name="product_long_description" id="textarea2" rows="3"><?php echo $product_info['product_long_description']?></textarea>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">product Image</label>
                        <div class="controls">
                            <input type="file" name="image">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Publication status </label>
                        <div class="controls">
                            <select class="form-control" name="publication_status">
                                <option value="">---select your publication status---</option>
                                <option value="1">Published</option>
                                <option value="0">Unpublished</option>
                            </select>
                        </div>
                    </div>   
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="btn">update product</button>
                        <button class="btn">Reset</button>
                    </div>
                </fieldset>
            </form>

        </div>
    </div><!--/span-->

</div><!--/row-->
<script>
 document.forms['edit_product_form'].elements['category_id'].value="<?php echo $product_info['category_id'];?>";
 document.forms['edit_product_form'].elements['menufeachures_id'].value="<?php echo $product_info['menufeachures_id'];?>";
 document.forms['edit_product_form'].elements['publication_status'].value="<?php echo $product_info['publication_status'];?>";
</script>
    

