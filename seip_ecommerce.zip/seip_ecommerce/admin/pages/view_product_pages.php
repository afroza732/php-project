<?php
$product_id = $_GET['product_id'];
$query_result =$obj_admin->select_product_info_by_id($product_id);
$product_info = mysqli_fetch_assoc($query_result);
?>

<table class="table table-bordered">
    <tbody>
        <tr>
            <td>Product Id</td>
            <td><?php echo $product_info['product_id']?></td>
        </tr>
        <tr>
            <td>Product Name</td>
            <td><?php echo $product_info['product_name'];?></td>
        </tr>
        <tr>
            <td>Category Name</td>
            <td><?php echo $product_info['category_name'];?></td>
        </tr>
        <tr>
            <td>Menufeature Name</td>
            <td><?php echo $product_info['menufeachures_name'];?></td>
        </tr>
        <tr>
            <td>Product Price</td>
            <td><?php echo $product_info['product_price'];?></td>
        </tr>
        <tr>
            <td>Product Quantity</td>
            <td><?php echo $product_info['product_quantity'];?></td>
        </tr>
        <tr>
            <td>Product Sku</td>
            <td><?php echo $product_info['product_sku'];?></td>
        </tr>
        <tr>
            <td>Product Short Description</td>
            <td><?php echo $product_info['product_short_description'];?></td>
        </tr>
        <tr>
            <td>Product Long Description</td>
            <td><?php echo $product_info['product_long_description'];?></td>
        </tr>
        <tr>
            <td>Image</td>
            <td>
                <img src="<?php echo $product_info['image']; ?>" alt="">
            </td>
        </tr>
        <tr>
            <td>Publication Status</td>
            <td>
                <?php
                if ($product_info['publication_status'] == 1) {
                    echo 'published';
                } else {
                    echo 'unpublished';
                }
                ?>
            </td>
        </tr>
    </tbody>
</table>
