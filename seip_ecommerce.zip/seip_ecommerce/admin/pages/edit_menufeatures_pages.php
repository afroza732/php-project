<?php
$admin_id = $_SESSION['admin_id'];
if ($admin_id == NULL) {
    header('Location: index.php');
}
$menufeachures_id=$_GET['menufeachures_id'];
$query_result=$obj_admin->select_menufeture_info_by_id($menufeachures_id);
$menufec_info= mysqli_fetch_assoc($query_result);


if (isset($_POST['btn'])) {
    $obj_admin->menufeture_update_info($_POST);
}
?>


<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Edit Menufeature Form </h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">
            <h2>
                <?php
                if (isset($message)) {
                    echo $message;
                    unset($message);
                }
                ?>
            </h2>
            <form class="form-horizontal" method="post" name="menufeture_forms">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Menufeature Name</label>
                        <div class="controls">
                            <input type="text" name="menufeachures_name" class="span6 typeahead" id="typeahead"  data-provide="typeahead" value="<?php echo $menufec_info['menufeachures_name'];?>">
                            <input type="hidden" name="menufeachures_id" class="span6 typeahead" id="typeahead"  data-provide="typeahead" value="<?php echo $menufec_info['menufeachures_id'];?>">
                        </div>
                    </div>        
                    <div class="control-group hidden-phone">
                        <label class="control-label" for="textarea2">Menufeature Description</label>
                        <div class="controls">
                            <textarea class="cleditor" id="textarea2" rows="3" name="menufeachures_description"><?php echo $menufec_info['menufeachures_description'];?></textarea>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Publication status </label>
                        <div class="controls">
                            <select class="form-control" name="publication_status">
                                <option value="">---select your publication status---</option>
                                <option value="1">Published</option>
                                <option value="0">Unpublished</option>
                            </select>
                        </div>
                    </div>   
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="btn">update mefeatures</button>
                        <button type="reset" class="btn">Reset</button>
                    </div>
                </fieldset>
            </form>   

        </div>
    </div><!--/span-->
    

</div><!--/row-->
<script>
    document.forms['menufeture_forms'].elements['publication_status'].value="<?php echo $menufec_info['publication_status']?>";
</script>
