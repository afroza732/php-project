<?php
session_start();

$_SESSION['name']='afroza';
$_SESSION['age']='22';
$_SESSION['country']='bangladesh';

