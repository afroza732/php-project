<?php
$pages='edit_product';
include './admin_master.php';
