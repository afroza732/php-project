<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$db_name = 'db_seip_ecommerce';

$conn = mysqli_connect($hostname, $username, $password);
if ($conn) {
    $db_select = mysqli_select_db($conn, $db_name);
    if ($db_select) {
       
    } else {
        die('connection error' . mysqli_error($db_select));
    }
} else {
    die('database connection error' . mysqli_error($conn));
}
?>

