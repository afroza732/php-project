<?php
$pages='category';
include './admin_master.php';
