<?php
    $pages='404';
    include './index.php';
?>
