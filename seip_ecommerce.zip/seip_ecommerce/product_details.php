<?php
$pages='product_details';
include './index.php';
