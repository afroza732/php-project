

<?php
 if(isset($_POST['btn'])){
        
        function save_catagory($data){
           $host ="localhost";
			$username ="root";
			$password ="";
			$db ="blog_db";

			$con  = mysqli_connect($host,$username,$password,$db);
			$permited  = array('jpg', 'jpeg', 'png', 'gif');
			$file_name = $_FILES['image']['name'];
			$file_size = $_FILES['image']['size'];
			$file_temp = $_FILES['image']['tmp_name'];

			$div = explode('.', $file_name);
			$file_ext = strtolower(end($div));
			$unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
			$uploaded_image = "upload/".$unique_image;
			 move_uploaded_file($file_temp, $uploaded_image);
           $sql ="INSERT INTO tbl_image(image)VALUES()'$data[image]')";
           
           if(mysqli_query($con, $sql)){
               
              $message ="Image upload successfully";
              return $message;
           }
           else{
               die('connection error'. mysqli_connect_error($con));
           }
            
        }
        
        $done = save_catagory($_POST);
    }

?>



<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<form action="" method="post">
	<table>
		<tr>
			<td>Image : </td>
			<td><input type="file" name="image"/></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="btn" value="upload"/></td>
		</tr>
	</table>
	</form>
</body>
</html>