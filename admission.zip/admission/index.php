<?php include './inc/header.php'; ?>
<?php include './inc/slider.php'; ?>


<?php include './inc/mainContent.php'; ?>

           
   
<?php include './inc/sidebar.php'; ?>
<?php include './inc/footer.php'; ?>
  
 