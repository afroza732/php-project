
<?php
ob_start();
include 'inc/header.php';
Session::checkSession();
?>
<br/>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Table</title>
        <!-- boostrap css-->
        <link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">

        <!-- file input css -->
        <link rel="stylesheet" type="text/css" href="assets/fileinput/css/fileinput.min.css">
        <link rel="stylesheet" type="text/css" href="assets/style.css">
    </head>
    <body>
        <form action="admissonAction.php" method="post" enctype="multipart/form-data" id="uploadImageForm" class="form-horizontal">
            <div class="col-md-8 col-sm-6 col-md-offset-2 col-sm-offset-3">  
                <table class="table" align="center" width="700px">
                    <tr bgcolor="#027A14">
                        <th colspan="10" class="text-center">
                            <a class="text-danger list-inline">Addmission Form  || </a>
                            <a href="Appoinment.php"class="text-danger item"> Appoinment Form</a>
                        </th>
                    </tr>
                </table>
            </div>
            <div class="col-md-5 col-sm-5 col-md-offset-4 col-sm-offset-4">

                <div id="messages"></div>
                <div class="form-group">

                    <div id="kv-avatar-errors-2" class="center-block" style="width:800px;display:none"></div>

                    <div class="kv-avatar center-block" style="width:200px">
                        <input id="avatar-2" name="image" type="file" class="file-loading">
                    </div>
                </div>
            </div>
            <!-- table start -->
            <div class="col-md-8 col-sm-6 col-md-offset-2 col-sm-offset-3">  
                <table class="table" align="center" width="700px">
                    <tr bgcolor="#027A14">
                        <th colspan="10">Personal Information</th>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Name<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="name" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }"></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Father Name<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="f_name" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }"></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Mother Name<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="m_name" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Present Address<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12"><textarea name="pre_address" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }"></textarea></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Permanent Address<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12"><textarea name="par_address" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }"></textarea></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Phone Number<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="phone" type="number" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Date Of Birth<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="date" type="date" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Gender<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3">
                            <label><input type="radio" name="gender" value="male" checked color="blue">Male</label>
                            <label><input type="radio" name="gender" value="female" checked>Female</label>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Religon<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="religion" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Email<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="email" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td> 
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Nationality<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="nationality" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td> 
                    </tr>
                    <tr>
                        <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">NID Number<span class="red12">*</span></td>
                        <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                        <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="nid_number" type="number" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                    this.value = this.value.toUpperCase();
                                }">
                        </td> 
                    </tr>
                </table>
                <table class="table table-bordered">
                    <thead>
                        <tr bgcolor="#027A14">
                            <th colspan="10">Educational Information</th>
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Institute Name<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="ins_name" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Program<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="program" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Passing Year<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="pass_year" type="number" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Remarks<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="e_remarks" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        </tbody>
                </table>
                <table class="table table-bordered">
                    <thead>
                        <tr bgcolor="#027A14">
                            <th colspan="10">Present/Job Information</th>
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Organization Name<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="orga_name" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Rank<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="rank" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Status<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="status" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        <tr>
                            <td align="left" valign="middle" bgcolor="#E3E3E3" class="black12">Remarks<span class="red12">*</span></td>
                            <td align="center" valign="middle" bgcolor="#E3E3E3" class="black12">:</td>
                            <td align="left" valign="middle" bgcolor="#E3E3E3"><input name="j_remarks" type="" class="textfield03" id="name" onkeypress="return alpha(event, letters)" onblur="javascript:{
                                        this.value = this.value.toUpperCase();
                                    }">
                            </td> 
                        </tr>
                        </tbody>
                </table>
                <!-- Course---->

                <table class="table table-bordered">
                    <tr  bgcolor="#027A14">
                        <th colspan="10">Course Information</th>
                    </tr>


                    <tr>
                        <td>Course Name</td>
                        <td>Course-01</td>
                        <td>Course-02</td>
                        <td>Course-03</td>
                    </tr>
                    <tr>
                        <td>Course Fees</td>
                        <td>12000</td>
                        <td>10000</td>
                        <td>80000</td>
                    </tr>
                    <tr>
                        <td>Course Duration</td>
                        <td>6 Month</td>
                        <td>3 Month</td>
                        <td>4 Month</td>
                    </tr>
                </table>
                <select
                    style="
                    width: 100%;
                    padding: .5%;
                    border: 2px solid #ddd;
                    font-size: 16px;
                    "  name="volvo_name">
                    <option value="">---Select Any One---</option>
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="mercedes">Mercedes</option>
                    <option value="audi">Audi</option>
                </select>

                <!-- educational start -->
            </div>

            <div class="subanddownload">
                <input type="submit" class="smv" name="btn" value="Submit and Download" style="
                       margin-left: 50%;
                       margin-top: 15px;
                       padding: 7px;
                       font-size: 16px;
                       background: #007A0B;
                       color: #fff;
                       margin-bottom:15px;
                       cursor:pointer;
                       ">
            </div>

            <!-- table end -->

        </form>

        <!-- jquery -->
        <script type="text/javascript" src="assets/jquery/jquery.min.js"></script>
        <!-- bootsrap js -->
        <script type="text/javascript" src="assets/bootstrap/js/bootstrap.min.js"></script>
        <!-- file input -->
        <script src="assets/fileinput/js/plugins/canvas-to-blob.min.js" type="text/javascript"></script>	
        <script src="assets/fileinput/js/plugins/sortable.min.js" type="text/javascript"></script>	
        <script src="assets/fileinput/js/plugins/purify.min.js" type="text/javascript"></script>
        <script src="assets/fileinput/js/fileinput.min.js"></script>

        <script type="text/javascript">
                                var btnCust = '<button type="button" class="btn btn-default" title="Add picture tags" ' +
                                        'onclick="alert(\'Call your custom code here.\')">' +
                                        '<i class="glyphicon glyphicon-tag"></i>' +
                                        '</button>';
                                $("#avatar-2").fileinput({
                                    overwriteInitial: true,
                                    maxFileSize: 1500,
                                    showClose: false,
                                    showCaption: false,
                                    showBrowse: false,
                                    browseOnZoneClick: true,
                                    removeLabel: '',
                                    removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
                                    removeTitle: 'Cancel or reset changes',
                                    elErrorContainer: '#kv-avatar-errors-2',
                                    msgErrorClass: 'alert alert-block alert-danger',
                                    defaultPreviewContent: '<img src="uploads/default-avatar.jpg" alt="Your Avatar" style="width:160px"><h6 class="text-muted">Click to select</h6>',
                                    layoutTemplates: {main2: '{preview} ' + btnCust + ' {remove} {browse}'},
                                    allowedFileExtensions: ["jpg", "png", "gif"]
                                });

                                $(document).ready(function () {
                                    $("#").unbind('submit').bind('submit', function () {

                                        var form = $(this);
                                        var formData = new FormData($(this)[0]);

                                        $.ajax({
                                            url: form.attr('action'),
                                            type: form.attr('method'),
                                            data: formData,
                                            dataType: 'json',
                                            cache: false,
                                            contentType: false,
                                            processData: false,
                                            async: false,
                                            success: function (response) {
                                                if (response.success == true) {
                                                    $("#messages").html('<div class="alert alert-success alert-dismissible" role="alert">' +
                                                            '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                                                            response.messages +
                                                            '</div>');

                                                    $('input[type="text"]').val('');
                                                    $(".fileinput-remove-button").click();
                                                } else {
                                                    $("#messages").html('<div class="alert alert-warning alert-dismissible" role="alert">' +
                                                            '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                                                            response.messages +
                                                            '</div>');
                                                }
                                            }
                                        });

                                        return false;
                                    });
                                });
        </script>
    </body>
</html>
<?php include './inc/footer.php'; ?>

