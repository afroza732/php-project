
<?php
ob_start();
include 'inc/header.php';
session::checkLogin();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login form</title>
        <style type="text/css">

            *{margin: 0px;padding: 0px;}
            body{margin: 0 auto;text-align: center;}
            .login-form{
                margin: 0 auto;
                margin-top: 40px;
                border: 2px solid #000;
                width: 870px;padding: 40px;
                margin-bottom: 50px;
            }
            .myinput{padding: 10px; }
            .error{ color: #ff0000;margin-bottom: 5px;}
        </style>
    </head>
    <body>
        <div class="login-form">
            <h2>Login Form</h2> <br> <br>
            <form class="myinput" method="post" action="">

                <input type="text" name="username" placeholder="UserName" /> <br> <br>
                <input type="text" name="password" placeholder="Password"/> <br> <br>
                <input type="submit" name="submit" value="Login"/> <br> <br>
                <?php
                $error = "";

                if (isset($_POST['submit'])) {
                    $username = $fm->validation($_POST['username']);
                    $password = $fm->validation(md5($_POST['password']));
                    $username = mysqli_real_escape_string($db->link, $username);
                    $password = mysqli_real_escape_string($db->link, $password);
                    if (empty($username) || empty($password)) {
                        echo '<span style="color:#c00">Both field are required!</span>';
                    } else {
                        $query = "select *  from  tbl_register where username='$username' and password='$password'";
                        $result = $db->select($query);
                        if ($result != false) {
                            $value = $result->fetch_assoc();
                            Session::set("login", true);
                            $_SESSION['username'] = $value['username'];
                            $_SESSION['id'] = $value['id'];
                            header('Location: home.php');
                        } else {
                            echo '<span style="color:#c00">Username or Password does not match!</span>';
                        }
                    }
                }
                ?> 

            </form>
            <div class="error"><?php echo $error ?></div> 

            Not Registrer? <a href="register.php">Signup Here</a>
        </div>
    </body>
</html>
<?php include './inc/footer.php'; ?>