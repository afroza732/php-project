<?php include './inc/header.php'; ?>
<?php include './inc/sidebar.php'; ?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Add New File</h2>
        <div class="block copyblock"> 
            <form action="" method="post" enctype="multipart/form-data">
                <table class="form">					
                    <tr>
                        <td>
                            <input type="file" name="filename"/>
                        </td>
                    </tr>
                    <tr> 
                        <td>
                            <input type="submit" name="upload" Value="Upload File" />
                        </td>
                    </tr>
                </table>
                <?php
                if (isset($_POST['upload'])) {
                    $permited = array('pdf', 'docx', 'zip', 'gif');
                    $file_name = $_FILES['filename']['name'];
                    $file_size = $_FILES['filename']['size'];
                    $file_temp = $_FILES['filename']['tmp_name'];
                    $div = explode('.', $file_name);
                    $file_ext = strtolower(end($div));
                    $folder = "media/" . $file_name;

                    if ($file_name == "") {
                        echo 'Field must not be empty !';
                    } elseif (in_array($file_ext, $permited) === false) {
                        echo "<span class='error'>You can upload only:-" . implode(', ', $permited) . "</span>";
                    } else {
                        move_uploaded_file($file_temp, $folder);
                        $query = "INSERT INTO  newfiles(filename)VALUES('$folder')";
                        $inserted_rows = $db->insert($query);
                        if ($inserted_rows) {
                            echo "<span class='success'>File Uploaded Successfully.  </span>";
                        } else {
                            echo "<span class='error'>File Not Uploaded !</span>";
                        }
                    }
                }
                ?>
            </form>
        </div>
    </div>
</div>
<?php include './inc/footer.php'; ?>
