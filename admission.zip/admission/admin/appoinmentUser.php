<?php include './inc/header.php'; ?>
<?php include './inc/sidebar.php'; ?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Appoinment User</h2>
        <?php
        if (isset($_GET['delete'])) {
            $id = $_GET['delete'];
            $sql = "SELECT * FROM  tbl_appoinment WHERE id = '$id'";
            $post_select = $db->select($sql);
            if ($post_select) {
                while ($result = $post_select->fetch_assoc()) {
                    $del_link = '../'.$result['image'];
                    unlink($del_link);
                }
            }
            $query = "DELETE FROM  tbl_appoinment WHERE id = '$id'";
            $post_delete = $db->delete($query);
            if ($post_delete) {
                echo "<script>alert('Post deleted successfully');</script>";
            } else {
                echo 'Post not  deleted successfully';
            }
        }
        ?>
        <div class="block">  
            <table class="data display datatable" id="example">
                <thead>
                    <tr>
                        <th width='5%'>Image</th>
                        <th width='10%'>name</th>
                        <th width='20%'>Address</th>
                        <th width='10%'>Phone Number</th>
                        <th width='10%'>Date of Birth</th>
                        <th width='5%'>Email</th>
                        <th width='5%'>Pass Year</th>
                        <th width='20%'>Institute Name</th>
                        <th width='10%'>Organigation Name</th>
                        <th width='10%'>Course Name</th>
                        <th width='10%'>Action</th>
                    </tr>
                </thead>
                <tbody> <?php
                    $query = "SELECT * FROM  tbl_appoinment";
                    $post_result = $db->select($query);
                    if ($post_result) {
                        while ($result = $post_result->fetch_assoc()) {
                            ?>

                            <tr class="odd gradeX">
                                <td><img src="<?php echo $result['image']; ?>" height="30px" width="40px"></td>
                                <td><?php echo $result['name']; ?></td>
                                <td><?php echo $result['par_address']; ?></td>
                                <td><?php echo $result['phone']; ?></td>
                                <td><?php echo $result['date']; ?></td>
                                <td><?php echo $result['email']; ?></td>
                                <td><?php echo $result['pass_year']; ?></td>
                                <td><?php echo $result['ins_name']; ?></td>
                                <td><?php echo $result['orga_name']; ?></td>
                                <td><?php echo $result['course_name']; ?></td>
                                 <td><a href="?delete=<?php echo $result['id']; ?>" onclick="return confirm('Are you sure Delete this !');">Delete</a>  </td>
                            </tr>

                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>

        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include './inc/footer.php'; ?>
