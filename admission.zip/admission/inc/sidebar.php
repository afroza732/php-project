
<div class="samesidebar clear" width="100%" height="100%" border="10px;">
    <h2>Message</h2>
    <div height="200px" width="200px" border="1px ">
        <?php
        $query = "SELECT * FROM tbl_category";
        $category = $db->select($query);
        if ($category) {
            while ($result = $category->fetch_assoc()) {
                ?>
                <ul>
                    <li><a href="posts.php?category_id=<?php echo $result['category_id']; ?>"><?php echo $result['category_name']; ?></a></li>
                    <?php
                }
            } else {
                ?>
                <li>No category</li>
            <?php } ?>
        </ul>
    </div>
</div>

<div class="samesidebar clear">
    <h2>Videos</h2>
    <div class="">
        <a>
            <iframe width="100%" height="188" src="https://www.youtube.com/embed/6T8stXj7Dzg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> 

        </a>
        <p></p>
        <a>
            <iframe width="100%" height="188" src="https://www.youtube.com/embed/AarHEO63JE0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </a>
        <p></p>
        <a>
            <iframe width="100%" height="188" src="https://www.youtube.com/embed/AarHEO63JE0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </a>
    </div>
</div>

</div>