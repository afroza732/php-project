
<?php include './config/config.php'; ?>
<?php include './lib/Database.php'; ?>
<?php

$db = new Database();
if (isset($_POST['btn'])) {
    $name = $_POST['name'];
    $f_name = $_POST['f_name'];
    $m_name = $_POST['m_name'];
    $pre_address = $_POST['pre_address'];
    $par_address = $_POST['par_address'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];
    $gender = $_POST['gender'];
    $religion = $_POST['religion'];
    $email = $_POST['email'];
    $nationality = $_POST['nationality'];
    $nid_number = $_POST['nid_number'];
    $ins_name = $_POST['ins_name'];
    $program = $_POST['program'];
    $pass_year = $_POST['pass_year'];
    $e_remarks = $_POST['e_remarks'];
    $orga_name = $_POST['orga_name'];
    $rank = $_POST['rank'];
    $status = $_POST['status'];
    $j_remarks = $_POST['j_remarks'];
    $skills = $_POST['skills'];
    $remarks = $_POST['remarks'];
    $course_name = $_POST['course_name'];


    $permited = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_temp = $_FILES['image']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10) . '.' . $file_ext;
    $folder = "uploads/" . $unique_image;


    if ($file_name == "") {
        echo 'Field must not be empty !';
    } elseif ($file_size > 1048567) {
        echo "<span class='error'>Image Size should be less then 1MB! </span>";
    } elseif (in_array($file_ext, $permited) === false) {
        echo "<span class='error'>You can upload only:-" . implode(', ', $permited) . "</span>";
    } else {
        move_uploaded_file($file_temp, $folder);
        $query = "INSERT INTO  tbl_appoinment(image,name,f_name,m_name,pre_address,par_address,phone,date,gender,religion,email,nationality,nid_number,ins_name,program,pass_year,e_remarks,orga_name,rank,status,j_remarks,skills,remarks,course_name) VALUES('$folder','$name','$f_name','$m_name','$pre_address','$par_address','$phone','$date','$gender','$religion','$email','$nationality','$nid_number','$ins_name','$program','$pass_year','$e_remarks','$orga_name','$rank','$status','$j_remarks','$skills','$remarks','$course_name')";
        $inserted_rows = $db->insert($query);
        if ($inserted_rows) {
            require('fpdf/fpdf.php');
            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Image($folder,11, 2, 30, 30);
            $pdf->Cell(0, 10, 'Welcome ' . $name, 0, 1, 'C');
            $pdf->Ln(15);
            $pdf->Cell(50, 10, "Name : " . $name, 0, 1);
            $pdf->Cell(50, 10, "Father Name : " . $f_name, 0, 1);
            $pdf->Cell(50, 10, "Mother Name : " . $m_name, 0, 1);
            $pdf->Cell(50, 10, "Present Address : " . $pre_address, 0, 1);
            $pdf->Cell(50, 10, "Parmanent Address : " . $par_address, 0, 1);
            $pdf->Cell(50, 10, "Phone : " . $phone, 0, 1);
            $pdf->Cell(50, 10, "Date Of Birth : " . $date, 0, 1);
            $pdf->Cell(50, 10, "Gender: " . $gender, 0, 1);
            $pdf->Cell(50, 10, "Email: " . $religion, 0, 1);
            $pdf->Cell(50, 10, "Nationality: " . $nationality, 0, 1);
            $pdf->Cell(50, 10, "NID Number: " . $nid_number, 0, 1);
            $pdf->Cell(50, 10, "Institute Name: " . $ins_name, 0, 1);
            $pdf->Cell(50, 10, "Program: " . $program, 0, 1);
            $pdf->Cell(50, 10, "Passing Year: " . $pass_year, 0, 1);
            $pdf->Cell(50, 10, "Remarks: " . $e_remarks, 0, 1);
            $pdf->Cell(50, 10, "Oraganization Name: " . $orga_name, 0, 1);
            $pdf->Cell(50, 10, "Rank: " . $rank, 0, 1);
            $pdf->Cell(50, 10, "Status: " . $status, 0, 1);
            $pdf->Cell(50, 10, "Skills: " . $skills, 0, 1);
            $pdf->Cell(50, 10, "Course Name: " . $course_name, 0, 1);
            $pdf->Output();
        } else {
            echo "<span class='error'>Data Not Inserted and Download!</span>";
        }
    }
}
?>