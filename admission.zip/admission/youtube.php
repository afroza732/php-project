<?php include './inc/header.php'; ?>
<div class="contentsection contemplete ">
    <div class="maincontent clear">
        <a>
            <iframe width="100%" height="213" src="https://www.youtube.com/embed/6T8stXj7Dzg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> 

        </a>
    </div>
    <div class="maincontent clear">
         <a>
            <iframe width="100%" height="213" src="https://www.youtube.com/embed/AarHEO63JE0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </a>
    </div>
    <div class="maincontent clear">
         <a>
            <iframe width="560" height="213" src="https://www.youtube.com/embed/pfD50KykFY8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </a>
    </div>
    <?php include './inc/sidebar.php'; ?>
    <?php include './inc/footer.php'; ?>

