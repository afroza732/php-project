<?php include './inc/header.php'; ?>
<div class="contentsection contemplete ">
    <div class="maincontent clear">

        <?php
        $query = "SELECT * FROM tbl_training WHERE id ='1'";
        $logo = $db->select($query);
        if ($logo) {
            while ($result = $logo->fetch_assoc()) {
                ?>
                <h2><?php echo $result['title']; ?></h2>
                <br/>
                <img src="admin/<?php echo $result['image']; ?>"  alt="Logo"/>
                <?php
            }
        }
        ?>
    </div>
    <div class="maincontent clear" height="300px" width="100%">

        <?php
        $query = "SELECT * FROM tbl_service WHERE id ='1'";
        $logo = $db->select($query);
        if ($logo) {
            while ($result = $logo->fetch_assoc()) {
                ?>
                <h2><?php echo $result['title']; ?></h2>
                <br/>
                <img src="admin/<?php echo $result['image']; ?>" alt="Logo"/>
                <?php
            }
        }
        ?>
    </div>
    <?php include './inc/sidebar.php'; ?>
    <?php include './inc/footer.php'; ?>

