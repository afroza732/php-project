

<?php
include './inc/header.php';

$sucess = " ";

if (isset($_POST['signup'])) {

    if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password'])) {

        $sucess = "Every filed must required";
    } else {

        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $username = stripcslashes($username);
        $email = stripcslashes($email);
        $password = stripcslashes($password);


        $password = md5($password);

        $query = "insert into tbl_register(username,email,password)
         values('$username','$email','$password')";
        $inserted_rows = $db->insert($query);


        if ($inserted_rows) {

            $sucess = "Success";
        } else {
            $sucess = "Error";
        }
    }
}
?>

<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <title>Register Form</title>
        <style type="text/css">

            *{margin: 0px;padding: 0px; !important}
            body{margin: 0 auto;text-align: center; !important}
            .regis-form{
                margin: 0 auto !important;
                margin-top: 40px !important;
                border: 2px solid #000 !important;
                width: 300px;padding: 40px !important;
            }
            .myinput{padding: 10px; !important}
            .success{color: #ff0000;margin-bottom: 5px;text-align: right;};
        </style>
    </head>
    <body>
        <div class="regis-form">
            <h2>Register Form</h2> <br> <br>
            <form class="myinput" method="post" action="">

                <input type="text" name="username" placeholder="UserName"/> <br> <br>
                <input type="email" name="email" placeholder="Email"/> <br> <br>
                <input type="text" name="password" placeholder="Password"/> <br> <br>
                <div class="success"><?php echo $sucess ?> <a href="login.php">Login</a> <?php ?></div> 
                <input type="submit" name="signup" value="Register"/> <br> <br>


            </form>

        </div>
    </body>
</html>
<br/>
<br/>
<?php
include './inc/footer.php';
?>