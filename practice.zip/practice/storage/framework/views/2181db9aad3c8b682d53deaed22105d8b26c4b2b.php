<html>
    <head>
        <title><?php echo $__env->yieldContent('content'); ?></title>
    </head>
    <body>
          hellow world
    </body>
</html>
