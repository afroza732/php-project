<html>
    <head>
        <title>@yield('content')</title>
    </head>
    <body>
          hellow world
    </body>
</html>
