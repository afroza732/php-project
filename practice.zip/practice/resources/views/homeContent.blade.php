@extends('main')

@section('content')
    afroza
@endsection