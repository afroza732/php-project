<?php include 'inc/header.php'; ?>
<?php
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $id);
    $message = $cart->cart_delete_info($id);
}
?>
<?php
if (isset($_POST['submit'])) {
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];
    $message = $cart->quantity_update_info($cart_id, $quantity);
    if ($quantity <= 0) {
        $message = $cart->cart_delete_info($cart_id);
    }
}
?>
<?php
//auto change
if (!isset($_GET['id'])) {
    echo "<meta http-equiv ='refresh' content ='0;URL=?id=live'/>";   
    
}

?>

<div class="main">
    <div class="content">
        <div class="cartoption">		
            <div class="cartpage">
                <h2>Your Cart</h2>
                <span style="color: teal; font-size: 15px;">
                    <?php
                    if (isset($message)) {
                        echo $message;
                        unset($message);
                    }
                    ?> 
                </span>
                <table class="tblone">
                    <tr>
                        <th width="5%">SL</th>
                        <th width="20%">Product Name</th>
                        <th width="10%">Image</th>
                        <th width="15%">Price</th>
                        <th width="25%">Quantity</th>
                        <th width="20%">Total Price</th>
                        <th width="10%">Action</th>
                    </tr>
                    <?php
                    $getCart = $cart->getCartValue();
                    if ($getCart) {

                        $getCartValue = $cart->selectAllCartValue();

                        $i = 0;
                        $sum = 0;
                        $quantity = 0;
                        while ($result = $getCartValue->fetch_assoc()) {
                            $i++;
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $result['product_name']; ?></td> 
                                <td><img src="admin/<?php echo $result['image']; ?>" height="70px" width="80px" alt=""/></td>
                                <td>Tk.<?php echo $result['price']; ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="cart_id" value="<?php echo $result['cart_id']; ?>"/>
                                        <input type="number" name="quantity" value="<?php echo $result['quantity']; ?>"/>
                                        <input type="submit" name="submit" value="Update"/>
                                    </form>
                                </td>
                                <td>
                                    TK.<?php
                                    $total = $result['price'] * $result['quantity'];
                                    echo $total;
                                    ?>
                                </td>
                                <td><a onclick="return confirm('Are you sure Delete this!')" href="?delete=<?php echo $result['cart_id']; ?>">X</a></td>
                            </tr>
                            <?php
                            $sum = $sum + $total;
                            $quantity = $quantity + $result['quantity'];
                            Session::set("sum", $sum);
                            Session::set("quantity",$quantity);
                            ?>
                        <?php } ?>
                    </table>

                    <table style="float:right;text-align:left;" width="40%">
                        <tr>
                            <th>Sub Total : </th>
                            <td>TK.<?php echo $sum; ?></td>
                        </tr>
                        <tr>
                            <th>VAT : </th>
                            <td>10%</td>
                        </tr>
                        <tr>
                            <th>Grand Total :</th>
                            <td>TK
                                <?php
                                $vat = $sum * 0.1;
                                $grandTotal = $sum + $vat;
                                echo $grandTotal;
                                ?>
                            </td>
                        </tr>
                    </table>
                <?php } else {?>
                <script>window.location = "index.php";</script>
              <?php  } ?>
            </div>
            <div class="shopping">
                <div class="shopleft">
                    <a href="index.php"> <img src="images/shop.png" alt="" /></a>
                </div>
                <div class="shopright">
                    <a href="payment.php"> <img src="images/check.png" alt="" /></a>
                </div>
            </div>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
</div>
<?php include 'inc/footer.php'; ?>