<?php include 'inc/header.php'; ?>
<?php
$id = Session::get("customer_id");
$result = $customer->getCustomerInformation($id);
?>
<?php
if (isset($_POST['update_btn'])) {
    $update = $customer->customer_profile_update($_POST,$id);
}
?>
<style>
    .register_account {
        height: 250px;
        margin-left: 200px;
        padding: 20px;
        width: 770px;
    }
</style>
<div class="main">
    <div class="content">
        <div class="register_account">
            <h3>Update Your Profile</h3>
            <span style="color: teal; font-size: 15px;">
                <?php
                if (isset($update)) {
                    echo $update;
                }
                ?>
            </span>
            <form action="" method="post">
                <center>
                    <table >
                        <tbody>
                            <tr>
                                <td>
                                    <div>
                                        <input type="text" name="customer_name" value="<?php echo $result['customer_name']; ?>">
                                    </div
                                    <div>
                                        <input type="text" name="customer_city" value="<?php echo $result['customer_city']; ?>">
                                    </div>

                                    <div>
                                        <input type="text" name="zip_code" value="<?php echo $result['zip_code']; ?>">
                                    </div>
                                    <div>
                                        <input type="text" name="customer_email" value="<?php echo $result['customer_email']; ?>">
                                    </div>

                                </td>
                                <td>
                                    <div>
                                        <input type="text" name="customer_address" value="<?php echo $result['customer_address']; ?>" >
                                    </div>

                                    <div>
                                        <input type="text" name="country" value="<?php echo $result['country']; ?>" >
                                    </div>
                                    <div>
                                        <input type="text" name="customer_phone" value="<?php echo $result['customer_phone']; ?>">
                                    </div>
                                    <div>
                                        <input type="text" name="customer_password" value="<?php echo $result['customer_password']; ?>">
                                    </div>
                                </td>
                            </tr> 
                        </tbody>
                    </table> 
                    <div class="search"><div><button class="grey" name="update_btn">Update Account</button></div></div>
                </center>
            </form>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
</div>
<?php include 'inc/footer.php'; ?>