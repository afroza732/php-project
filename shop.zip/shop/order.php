<?php include 'inc/header.php'; ?>
<?php
$login = Session::get("login");
if ($login == FALSE) {
    header("Location: order.php");
}
?>
<div class="contentsection contemplete clear">
    <div class="maincontent clear">
        <div class="about">
            <div class="notfound">
                <h3>Order Page</h3>
            </div>
        </div>
    </div>
    <?php include 'inc/footer.php'; ?>