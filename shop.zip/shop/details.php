<?php include 'inc/header.php'; ?>
<?php
if (!isset($_GET['product_id']) || $_GET['product_id'] == NULL) {
    echo "<script>window.location  = '404.php';</script>";
} else {
    $product_id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $_GET['product_id']);
}

if (isset($_POST['submit'])) {
    // $quantity = $_POST['quantity'];
    $cart_details = $cart->addToCart($_POST, $product_id);
}
?>
<div class="main">
    <div class="content">
        <div class="section group">
            <div class="cont-desc span_1_of_2">	
                <?php
                $details_product = $product->select_details_product($product_id);
                ?>
                <div class="grid images_3_of_2">
                    <img src="admin/<?php echo $details_product['image']; ?>" height="100px" width="200px" alt="" />
                </div>
                <div class="desc span_3_of_2">
                    <h2><?php echo $details_product['product_name']; ?></h2>
                    <div class="price">
                        <p>Price: <span>$<?php echo $details_product['price']; ?></span></p>
                        <p>Category: <span><?php echo $details_product['category_name']; ?></span></p>
                        <p>Brand:<span><?php echo $details_product['brand_name']; ?></span></p>
                    </div>
                    <div class="add-cart">
                        <form action="" method="post">
                            <input type="number" class="buyfield" name="quantity" value="1"/>
                            <input type="submit" class="buysubmit" name="submit" value="Buy Now"/>
                        </form>	
                        <span style="color: red; font-size:16px; align: center; padding-top:20px;">
                            <?php
                            if (isset($cart_details)) {
                                echo $cart_details;
                            }
                            ?> 
                        </span>
                    </div>
                </div>
                <div class="product-desc">
                    <h2>Product Details</h2>
                    <p><?php echo $details_product['body']; ?></p>
                </div>

            </div>
            <div class="rightsidebar span_3_of_1">

                <h2>CATEGORIES</h2>
                <?php
                $select_category = $Category->all_category_select_info();
                while ($result = $select_category->fetch_assoc()) {
                    ?>
                    <ul>
                        <li><a href="productbycat.php?category_id=<?php echo $result['category_id']; ?>"><?php echo $result['category_name']; ?></a></li>
                    </ul>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>