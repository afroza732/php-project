﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Brand.php'; ?>
<?php include '../classes/Category.php'; ?>
<?php include '../classes/Product.php'; ?>
<?php
$Category = new Category();
$category_result = $Category->all_category_select_info()
?>
<?php
$Brand = new Brand();
$brand_result = $Brand->all_brand_select_info();
?>

<?php
if (isset($_POST['submit'])) {
    $obj_product = new Product();
    $message = $obj_product->product_all_save_info($_POST);
}
?>


<div class="grid_10">
    <div class="box round first grid">
        <h2>Add New Product</h2>

        <span style="color: teal; font-size: 15px;">
            <?php
            if (isset($message)) {
                echo $message;
                unset($message);
            }
            ?> 
            <div class="block">               
                <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">

                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="product_name" placeholder="Enter Product Name..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="category_id">
                                    <option>----Select Category----</option>
                                    <?php
                                    while ($result = $category_result->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $result['category_id']; ?>"><?php echo $result['category_name']; ?></option>

                                    <?php } ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Brand</label>
                            </td>
                            <td>
                                <select id="select" name="brand_id">
                                    <option>----Select Brand----</option>
                                    <?php
                                    while ($result = $brand_result->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $result['brand_id']; ?>"><?php echo $result['brand_name']; ?></option>

                                    <?php } ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Description</label>
                            </td>
                            <td>
                                <textarea class="" name="body" style="width:55%; height:300px;"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Price</label>
                            </td>
                            <td>
                                <input type="text" name="price" placeholder="Enter Price..." class="medium" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name="image"/>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>Product Type</label>
                            </td>
                            <td>
                                <select id="select" name="type">
                                    <option>Select Type</option>
                                    <option value="0">Featured</option>
                                    <option value="1">General</option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Product Save" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
    </div>
</div>
<!-- Load TinyMCE -->
<?php include 'inc/footer.php'; ?>


