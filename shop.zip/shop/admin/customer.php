﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Customer.php'; ?>
<?php
if (!isset($_GET['cusmoerId']) || $_GET['cusmoerId'] == NULL) {
    echo "<script>window.location  = 'inbox.php';</script>";
} else {
    $id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $_GET['cusmoerId']);
}
?>
<?php
if (isset($_POST['btn'])) {
    echo "<script>window.location  = 'inbox.php';</script>";
}
?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>Update Category</h2>
        <div class="block copyblock"> 
            <?php $obj_customer = new Customer();
            $result = $obj_customer->getCustomerInformation($id);
            ?>
            <form action="" method="post">
                <table class="form">					
                    <tr>
                        <td>Name:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['customer_name']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>City:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['customer_city']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>Zip Code:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['zip_code']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['customer_email']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>Address:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['customer_address']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>Country:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['country']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>Phone:</td>
                        <td>
                            <input type="text" readonly="readonly" value="<?php echo $result['customer_phone']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr> 
                        <td>
                            <input type="submit" name="btn" Value="Ok" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>

