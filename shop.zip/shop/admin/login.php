<?php include '../classes/AdminLogin.php';?>

<?php
$adminLogin = new AdminLogin;
if (isset($_POST['btn'])) {
    $admin_username = $_POST['admin_username'];
    $admin_password = md5($_POST['admin_password']);

    $loginCheck = $adminLogin->login_admin($admin_username, $admin_password);
}
?>

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
    <div class="container">
        <section id="content">
            <form action="login.php" method="post">
                <h1>Admin Login</h1>
                <span style="color: #c00; font-size: 15px;">
                    <?php
                   if (isset($loginCheck)) {
                        echo $loginCheck;
                    }
                    ?> 
                </span>
                <div>
                    <input type="text" placeholder="Username"  name="admin_username"/>
                </div>
                <div>
                    <input type="password" placeholder="Password"  name="admin_password"/>
                </div>
                <div>
                    <input type="submit" name="btn" value="Log in" />
                </div>
            </form><!-- form -->
            <div class="button">
                <a href="#">Training with live project</a>
            </div><!-- button -->
        </section><!-- content -->
    </div><!-- container -->
</body>
</html>