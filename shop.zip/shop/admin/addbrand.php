﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Brand.php'; ?>
<?php
$obj_brand = new Brand();
if (isset($_POST['btn'])) {
    $message = $obj_brand->brand_save_info($_POST);
}
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Add New Brand</h2>
        <span style="color: teal; font-size: 15px;">
            <?php
            if (isset($message)) {
                echo $message;
                unset($message);
            }
            ?> 
        </span>
        <div class="block copyblock"> 
            <form action="" method="post">
                <table class="form">					
                    <tr>
                        <td>
                            <input type="text" name="brand_name" placeholder="Enter Brand Name..." class="medium" />
                        </td>
                    </tr>
                    <tr> 
                        <td>
                            <input type="submit" name="btn" Value="Save" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>