﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Category.php'; ?>
<?php
 
if (!isset($_GET['category_id']) || $_GET['category_id'] == NULL) {
    echo "<script>window.location  = 'catlist.php';</script>";
} else {
    $category_id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $_GET['category_id']);
}
?>
<?php
$obj_category = new Category();
$result = $obj_category->select_category_info_by_id($category_id);
if (isset($_POST['btn'])) {
    $message = $obj_category->category_update_info($_POST,$category_id);
}
?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>Update Category</h2>
        <span style="color: teal; font-size: 15px;">
            <?php
            if (isset($message)) {
                echo $message;
                unset($message);
            }
            ?> 
        </span>
        <div class="block copyblock"> 
            <form action="" method="post">
                <table class="form">					
                    <tr>
                        <td>
                            <input type="text" name="category_name" value="<?php echo $result['category_name']; ?>" class="medium" />
                        </td>
                    </tr>
                    <tr> 
                        <td>
                            <input type="submit" name="btn" Value="Update Category" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>