﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Brand.php'; ?>
<?php include '../classes/Category.php'; ?>
<?php include '../classes/Product.php'; ?>
<?php
if (!isset($_GET['product_id']) || $_GET['product_id'] == NULL) {
    echo "<script>window.location  = 'productlist.php';</script>";
} else {
    $product_id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $_GET['product_id']);
}
$obj_product = new Product();
?>
<?php
$Category = new Category();
$category_result = $Category->all_category_select_info();
?>
<?php
$Brand = new Brand();
$brand_result = $Brand->all_brand_select_info();
?>
<?php 
$product_result = $obj_product->select_product_info_by_id($product_id) ;

?>
<?php
if (isset($_POST['update'])) {
    $message = $obj_product->product_update_info_by_id($_POST,$product_id);
}
?>


<div class="grid_10">
    <div class="box round first grid">
        <h2>Edit Product</h2>

        <span style="color: teal; font-size: 15px;">
            <?php
            if (isset($message)) {
                echo $message;
                unset($message);
            }
            ?> 
            <div class="block">               
                <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">

                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="product_name" value="<?php echo $product_result['product_name'] ;?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="category_id">
                                    <option>----Select Category----</option>
                                    <?php
                                    while ($result= $category_result->fetch_assoc()) {
                                        ?>
                                        <option 
                                            <?php
                                            if($product_result['category_id'] == $result['category_id']){?>
                                            selected="selected"
                                           
                                          <?php }?>  value="<?php echo $result['category_id']; ?>"><?php echo $result['category_name']; ?>
                                        </option>

                                    <?php }?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Brand</label>
                            </td>
                            <td>
                                <select id="select" name="brand_id">
                                    <option>----Select Brand----</option>
                                    <?php
                                    while ($result = $brand_result->fetch_assoc()) {
                                        ?>
                                        <option 
                                             <?php
                                            if($product_result['brand_id'] == $result['brand_id']){?>
                                            selected="selected"
                                           <?php }?> value="<?php echo $result['brand_id']; ?>"><?php echo $result['brand_name']; ?>
                                        </option>

                                    <?php } ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Description</label>
                            </td>
                            <td>
                                <textarea class=""  name="body" style="width:55%;"><?php echo $product_result['body'] ;?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Price</label>
                            </td>
                            <td>
                                <input type="text" name="price" value="<?php echo $product_result['price'] ;?>" class="medium" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <img src="<?php echo $product_result['image'] ;?>" height="100px" width="150px">
                                <input type="file"  name="image"/>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>Product Type</label>
                            </td>
                            <td>
                                <select id="select" name="type">
                                    <option>Select Type</option>
                                    <?php
                                    if($product_result['type'] == 0){ ?>
                                    <option value="0" selected="selected">Featured</option>
                                      <option value="1">General</option>    
                                     
                                   <?php   } else{ ?> 
                                   <option value="1" selected="selected">General</option>
                                    <option value="0">Featured</option>    
                                   <?php } ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="update" Value="Product Update" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>


