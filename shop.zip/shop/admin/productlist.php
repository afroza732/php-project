﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Product.php'; ?>
<?php include '../classes/Category.php'; ?>
<?php include '../classes/Brand.php'; ?>
<?php
$db = new Database();
$fm = new Format();
?>
<?php
$product = new Product();
$product_result = $product->all_product_select_info();
?>
<?php
if (isset($_GET['status'])) {
    $id = $_GET['status'];
    $id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $id);
    $message = $product->product_delete_info_by_id($id);
}
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Product List</h2>
        <span style="color: teal; font-size: 15px; align: center;">
            <?php
            if (isset($message)) {
                echo $message;
                unset($message);
            }
            ?> 
            <div class="block">  
                <table class="data display datatable" id="example">
                    <thead>
                        <tr>
                            <th>No </th>
                            <th>Product Name</th>
                            <th>Category Name</th>
                            <th>Brand Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Product Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($result = $product_result->fetch_assoc()) {
                            $i++;
                            ?>
                            <tr class="odd gradeX">
                                <td><?php echo $i; ?></td>
                                <td><?php echo $result['product_name']; ?></td>
                                <td><?php echo $result['category_name']; ?></td>
                                <td><?php echo $result['brand_name']; ?></td>
                                <td><?php echo $fm->textShorten($result['body'],50); ?></td>
                                <td>$<?php echo $result['price']; ?></td>
                                <td><img src="<?php echo $result['image']; ?>" alt="" height="50px" width="70px"></td>
                                <td>
                                    <?php 
                                    if($result['type']=='0'){
                                        echo 'Featured';  
                                    }else{
                                       echo 'General';  
                                    } 
                                    ?>
                                </td>
                                <td>
                                    <a href="editProduct.php?product_id=<?php echo $result['product_id'];?> ">Edit</a> ||
                                    <a href="?status=<?php echo $result['product_id'];?>" onclick="return confirm('Are you sure Delete  this category !');">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>

            </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php'; ?>
