﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include '../classes/Cart.php'; ?>

<?php
if (isset($_GET['shift_id'])) {
    $id = $_GET['shift_id'];
    $price = $_GET['price'];
    $date = $_GET['date'];
    $shift = $cart->productShifted($id, $price, $date);
}
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Inbox</h2>
        <div class="block">        
            <table class="data display datatable" id="example">
                <thead>
                    <tr>
                        <th>ID No.</th>
                        <th>Order Time</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Adress</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $cart = new Cart();
                    $fm = new Format();
                    $getOrder = $cart->getOrderInfo();
                    if ($getOrder) {
                        $i = 0;
                        while ($result = $getOrder->fetch_assoc()) {
                            $i++;
                            ?>
                            <tr class="odd gradeX" style="text-align:center;">
                                <td><?php echo $result['product_id']; ?></td> 
                                <td><?php echo $fm->formatDate($result['date']); ?></td>
                                <td><?php echo $result['product_name']; ?></td> 
                                <td><?php echo $result['quantity']; ?></td> 
                                <td><?php echo $result['price']; ?></td> 
                                <td><a href="customer.php?cusmoerId=<?php echo $result['customer_id']; ?>">View Details</a></td> 
                                <?php if ($result['status'] == 0) { ?>
                                    <td><a href="?shift_id =<?php echo $result['product_id']; ?>& price=<?php echo $result['price']; ?>& date=<?php echo $result['date']; ?>">Shifted</a></td>    
                                <?php } else { ?>
                                    <td><a href="?shift_id =<?php echo $result['product_id']; ?>& price=<?php echo $result['price']; ?>& date=<?php echo $result['date']; ?>">Remove</a></td>    
                                <?php }
                            }
                        }
                        ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php'; ?>
