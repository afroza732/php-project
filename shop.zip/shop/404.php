<?php include 'inc/header.php'; ?>
<div class="contentsection contemplete clear">
    <div class="maincontent clear">
        <div class="about">
            <div class="notfound">
                <h2><span>404</span> Not Found</h2>
            </div>
        </div>
    </div>
    <?php include 'inc/footer.php'; ?>