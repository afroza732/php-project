<?php include 'inc/header.php'; ?>
<?php
$login = Session::get("login");
if ($login == FALSE) {
    header("Location:login.php");
}
?>
<style>
    .success {
        width: 500px;
        min-height: 200px;
        text-align: center;
        border: 1px solid #ddd;
        margin: 0 auto;
    }

    .success p{
        font-size: 18px;
        line-height: 25px;
        text-align: left;

    }
    .success h2{
        border-bottom:1px solid #ddd;
        margin-bottom:30px;
        padding: 10px;
    }
    .back a{
        width: 160px;
        margin:10px auto 0;
        padding: 7px 0;
        text-align: center;
        display: block;
        background: #555;
        border: 1px solid #333;
        color: #fff;
        font-size: 25px;
        border-radius: 3px;
    }

</style>
<div class="main">
    <div class="content">
        <div class="section group">
            <div class="success">
                <h2>Success</h2>
                <?php
                $customer_id = Session::get("customer_id");
                $amount = $cart->select_price_info($customer_id);
                if ($amount) {
                    $sum = 0;
                    while ($result = $amount->fetch_assoc()) {
                        $price = $result['price'];
                        $sum = $sum + $price;
                    }
                }
                ?>
                <p> Total payable Amount(Including vat) : $
                    <?php
                    $vat = $sum * 0.1;
                    $total = $vat + $sum;
                    echo $total;
                    ?>
                </p>
                <p>
                    Thank you for purchase.Recieve your order successfully.
                    We will contact ASAP with order Details....
                    <a href="orderDetails.php">Visit Here...</a>
                </p>
            </div>
            <div class="back">
                <a href="cart.php">Back</a>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>