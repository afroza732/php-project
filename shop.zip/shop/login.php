<?php include 'inc/header.php'; ?>

<?php
if (isset($_POST['login'])) {
    $login = $customer->customer_login($_POST);
}
?>

<?php
$login = Session::get("login");
if ($login == TRUE) {
    header("Location: index.php");
}
?>
<div class="main">
    <div class="content">
        <div class="login_panel">
            <h3>Existing Customers</h3>
            <p>Sign in with the form below.</p>
            <span style="color: teal; font-size: 15px;">
                <?php
                if (isset($login)) {
                    echo $login;
                }
                ?>
                <form action="" method="post">
                    <input type="text" name="customer_email" placeholder="Email" >
                    <input type="text" name="customer_password" placeholder="Password" >
                    <div class="buttons"><div><button class="grey" name="login">Sign In</button></div></div>
                </form>
        </div>
        <div class="register_account">
            <h3>Register New Account</h3>
            <span style="color: teal; font-size: 15px;">
                <?php
                if (isset($_POST['register'])) {
                    $Register = $customer->customer_registration($_POST);
                    if ($Register) {
                        echo $Register;
                    }
                }
                ?>
            </span>
            <form action="" method="post">
                <table>
                    <tbody>
                        <tr>
                            <td>
                                <div>
                                    <input type="text" name="customer_name" placeholder="Name" >
                                </div
                                <div>
                                    <input type="text" name="customer_city" placeholder="City" >
                                </div>

                                <div>
                                    <input type="text" name="zip_code" placeholder="Zip-Code" >
                                </div>
                                <div>
                                    <input type="text" name="customer_email" placeholder="Email" >
                                </div>

                            </td>
                            <td>
                                <div>
                                    <input type="text" name="customer_address" placeholder="Address" >
                                </div>
                                <div>
                                    <input type="text" name="country" placeholder="Country" > 
                                </div>		        

                                <div>
                                    <input type="text" name="customer_phone" placeholder="Phone" >
                                </div>
                                <div>
                                    <input type="text" name="customer_password" placeholder="Password" >
                                </div>
                            </td>
                        </tr> 
                    </tbody></table> 
                <div class="search"><div><button class="grey" name="register">Create Account</button></div></div>
                <p class="terms">By clicking 'Create Account' you agree to the <a href="#">Terms &amp; Conditions</a>.</p>
                <div class="clear"></div>
            </form>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
</div>
<?php include 'inc/footer.php'; ?>