<?php include 'inc/header.php'; ?>
<?php
$login = Session::get("login");
if ($login == FALSE) {
    header("Location:login.php");
}
?>
<style>
    .division{
        width:50%;
        float: left;
    }
    .tablOne {
        width:550px;
        margin: 0 auto;
        border: 2px solid #ddd;
    }
    .tablOne tr td{
        text-align: justify; 
        padding:5px;
        border: 2px solid #ddd;
    }
    .tblTwo {
        width: 60%;
        float: right;
        text-align: left;
        border: 2px solid #ddd;
        margin-right:14px;
        margin-top: 12px;
    }
    .tblTwo tr td{
        text-align: justify; padding:5px;
    }

    .back a{
        width: 160px;
        margin:10px auto 0;
        padding: 7px 0;
        text-align: center;
        display: block;
        background:#074676;
        border: 1px solid #333;
        color: #fff;
        font-size: 25px;
        border-radius: 3px;
    }

</style>
<div class="main">
    <div class="content">
        <div class="section group">
            <div class="division">
                <table class="tblone">
                    <tr>
                        <th width="5%">No</th>
                        <th width="20%">Produt</th>
                        <th width="15%">Price</th>
                        <th width="25%">Quantity</th>
                        <th width="20%">Total Price</th>
                    </tr>
                    <?php
                    $getCart = $cart->getCartValue();
                    if ($getCart) {

                        $getCartValue = $cart->selectAllCartValue();

                        $i = 0;
                        $sum = 0;
                        $quantity = 0;
                        while ($result = $getCartValue->fetch_assoc()) {
                            $i++;
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $result['product_name']; ?></td> 
                                <td>Tk.<?php echo $result['price']; ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="cart_id" value="<?php echo $result['cart_id']; ?>"/>
                                        <input type="number" name="quantity" value="<?php echo $result['quantity']; ?>"/>
                                        <input type="submit" name="submit" value="Update"/>
                                    </form>
                                </td>
                                <td>
                                    TK.<?php
                                    $total = $result['price'] * $result['quantity'];
                                    echo $total;
                                    ?>
                                </td>
                            </tr>
                            <?php
                            $sum = $sum + $total;
                            $quantity = $quantity + $result['quantity'];
                            ?>
                        <?php } ?>
                    </table>
                    <table class="tblTwo">
                        <tr>
                            <td>Sub Total </td>
                            <td>:</td>
                            <td>TK.<?php echo $sum; ?></td>
                        </tr>
                        <tr>
                            <td>VAT </td>
                            <td>:</td>
                            <td>10% ($<?php echo $sum; ?>)</td>
                        </tr>
                        <tr>
                            <td>Grand Total</td>
                            <td>:</td>
                            <td>TK
                                <?php
                                $vat = $sum * 0.1;
                                $grandTotal = $sum + $vat;
                                echo $grandTotal;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Quantity</td>
                            <td>:</td>
                            <td><?php echo $quantity; ?></td>
                        </tr>
                    </table>
                <?php } else { ?>
                    <script>window.location = "index.php";</script>
                <?php } ?>
            </div>

            <div class="division">
                <form action="" method="post">
                    <table class="tablOne" >

                        <?php
                        $id = Session::get("customer_id");
                        $result = $customer->getCustomerInformation($id);
                        ?>
                        <tbody>
                            <tr>
                                <td colspan="3">
                                    <h3 style="text-align:center; font-size: 25px; color: teal; font-weight: bolder;">Your Profile</h3>
                                </td>

                            </tr>  
                            <tr>
                                <td>Name </td>
                                <td>:</td>
                                <td><?php echo $result['customer_name']; ?></td>
                            </tr>  
                            <tr>
                                <td>City</td>
                                <td>:</td>
                                <td><?php echo $result['customer_city']; ?></td>
                            </tr>  
                            <tr>
                                <td>Zip Code</td>
                                <td>:</td>
                                <td><?php echo $result['zip_code']; ?></td>
                            </tr>  
                            <tr>
                                <td>Email</td>
                                <td>:</td>
                                <td><?php echo $result['customer_email']; ?></td>
                            </tr>  
                            <tr>
                                <td>Address</td>
                                <td>:</td>
                                <td><?php echo $result['customer_address']; ?></td>
                            </tr>  
                            <tr>
                                <td>Country</td>
                                <td>:</td>
                                <td><?php echo $result['country']; ?></td>
                            </tr>  
                            <tr>
                                <td>Phone</td>
                                <td>:</td>
                                <td><?php echo $result['customer_phone']; ?></td>
                            </tr>  
                            <tr>
                                <td colspan="3">
                                    <a href="editProfile.php" style="display: block; text-align: center; font-size: 20px; color: teal; font-weight: bolder;">Update Profile</a>
                                </td>

                            </tr>  
                        </tbody>
                    </table>   
                </form>
            </div>

        </div>
        <div class="back">
        <a href="offPayment.php?order_id=order">Order</a>
    </div>
    </div>
    
</div>
<?php include 'inc/footer.php'; ?>

