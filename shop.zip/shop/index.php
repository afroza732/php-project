<?php include 'inc/header.php'; ?>
<?php include 'inc/slider.php'; ?>



<div class="main">
    <div class="content">
        <div class="content_top">
            <div class="heading">
                <h3>Feature Products</h3>
            </div>
            <div class="clear"></div>
        </div>
        <div class="section group">
            <?php
            $product_features = $product->select_features_info();
            if ($product_features) {

                while ($result = $product_features->fetch_assoc()) {
                    ?>
                    <div class="grid_1_of_4 images_1_of_4">
                        <a href="details.php?product_id=<?php echo $result['product_id']; ?>"><img src="admin/<?php echo $result['image']; ?>" height="200px"  alt="" /></a>
                        <h2><?php echo $result['product_name']; ?></h2>
                        <p><?php echo $fm->textShorten($result['body'], 30); ?></p>
                        <p><span class="price">$<?php echo $result['price']; ?></span></p>
                        <div class="button"><span><a href="details.php?product_id=<?php echo $result['product_id']; ?>" class="details">Details</a></span></div>
                    </div>
                <?php
                }
            }
            ?>
        </div>
        <div class="content_bottom">
            <div class="heading">
                <h3>New Products</h3>
            </div>
            <div class="clear"></div>
             <div class="section group">
            <?php
            $new_products = $product->select_all_new_product();
            if ($new_products) {

                while ($result = $new_products->fetch_assoc()) {
                    ?>
                    <div class="grid_1_of_4 images_1_of_4">
                        <a href="details.php?product_id=<?php echo $result['product_id']; ?>"><img src="admin/<?php echo $result['image']; ?>" height="150" alt="" /></a>
                        <h2><?php echo $result['product_name']; ?></h2>
                        <p><?php echo $fm->textShorten($result['body'], 30); ?></p>
                        <p><span class="price">$<?php echo $result['price']; ?></span></p>
                        <div class="button"><span><a href="details.php?product_id=<?php echo $result['product_id']; ?>" class="details">Details</a></span></div>
                    </div>
                <?php
                }
            }
            ?>
        </div>
        </div>
       
    </div>
</div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>