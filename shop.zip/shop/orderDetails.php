<?php include 'inc/header.php'; ?>
<div class="contentsection contemplete clear">
    <div class="maincontent clear">
        <div class="order">
            <div class="notfound">
                <h4>Your Order Details</h4>
            </div>
            <table class="tblone">
                <tr>
                    <th width="5%">SL</th>
                    <th width="20%">Product Name</th>
                    <th width="10%">Image</th>
                    <th width="25%">Quantity</th>
                    <th width="15%">Price</th>
                    <th width="20%">Date</th>
                    <th width="20%">Status</th>
                    <th width="10%">Action</th>
                </tr>
                <?php
                $customer_id = Session::get("customer_id");
                $getOrder = $cart->getOrderValue($customer_id);
                if ($getOrder) {
                    $i = 0;
                    while ($result = $getOrder->fetch_assoc()) {
                        $i++;
                        ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $result['product_name']; ?></td> 
                            <td><img src="admin/<?php echo $result['image']; ?>" height="70px" width="80px" alt=""/></td>
                            <td><?php echo $result['quantity']; ?></td>
                            <td>
                                TK.<?php
                                $total = $result['price'] * $result['quantity'];
                                echo $total;
                                ?>
                            </td>
                            <td><?php echo $fm->formatDate($result['date']); ?></td>
                            <td>
                                <?php
                                if ($result['status'] == 0) {
                                    echo 'Pending';
                                } else {
                                    echo 'Shifted';
                                }
                                ?>
                            </td>
                            <?php if ($result['status'] == 1) { ?>
                                <td><a onclick="return confirm('Are you sure Delete this!')" href="">X</a></td>
                            <?php } else { ?>
                                <td>N/A</td>  
                            <?php } ?>
                        </tr>
                    <?php }
                }
                ?>
            </table>
        </div>
    </div>
    <?php include 'inc/footer.php'; ?>
