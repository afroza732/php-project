<?php include 'inc/header.php'; ?>
<?php

if (isset($_GET['order_id']) || $_GET['order_id'] == 'order') {
    $customer_id = Session::get("customer_id");
    $order = $cart->getOrderInformation($customer_id);
    $cartDelete = $cart->cartDeleteInfo();
    header("Location: successPage.php");
}
?>
<?php include 'inc/footer.php'; ?>