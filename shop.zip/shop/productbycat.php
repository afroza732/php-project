<?php include 'inc/header.php'; ?>
<?php
if (!isset($_GET['category_id']) || $_GET['category_id'] == NULL) {
    echo "<script>window.location  = '404.php';</script>";
} else {
    $category_id = preg_replace('/[^a-zA-Z0-9 -]/', ' ', $_GET['category_id']);
}
?>
<div class="main">
    <div class="content">
        <div class="content_top">
            <div class="heading">
                <h3>Latest from Category</h3>
            </div>
            <div class="clear"></div>
        </div>
        <div class="section group">
            <?php
            $getproductByCat = $product->viewProductInfoByCategory($category_id);
            if ($getproductByCat) {
                while ($result = $getproductByCat->fetch_assoc()) {
                    ?>
                    <div class="grid_1_of_4 images_1_of_4">
                        <a href="details.php?product_id=<?php echo $result['product_id']; ?>"><img src="admin/<?php echo $result['image']; ?>" height="200px"  alt="" /></a>
                        <h2><?php echo $result['product_name']; ?></h2>
                        <p><?php echo $fm->textShorten($result['body'], 30); ?></p>
                        <p><span class="price">$<?php echo $result['price']; ?></span></p>
                        <div class="button"><span><a href="details.php?product_id=<?php echo $result['product_id']; ?>" class="details">Details</a></span></div>
                    </div>
                <?php }
            } else{ echo "<script>window.location  = '404.php';</script>"; } ?>
        </div>



    </div>
</div>
</div>
