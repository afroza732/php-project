<?php include 'inc/header.php'; ?>
<?php
$id = Session::get("customer_id");
$result = $customer->getCustomerInformation($id);
?>

<style>
    .register_account {
        height: 280px;
        margin-left:300px;
        padding: 20px;
        width:500px;
    }
    .tablOne{margin: 0 auto;}
    .tablOne tr td{text-align: justify; padding:5px;}
</style>
<div class="main">
    <div class="content">
        <div class="register_account">
            <h3>Your Profile</h3>
            <form action="" method="post">
                <center>
                    <table class="tablOne" >
                        <tbody>
                            <tr>
                                <td>Name </td>
                                <td>:</td>
                                <td><?php echo $result['customer_name']; ?></td>
                            </tr>  
                            <tr>
                                <td>City</td>
                                <td>:</td>
                                <td><?php echo $result['customer_city']; ?></td>
                            </tr>  
                            <tr>
                                <td>Zip Code</td>
                                <td>:</td>
                                <td><?php echo $result['zip_code']; ?></td>
                            </tr>  
                            <tr>
                                <td>Email</td>
                                <td>:</td>
                                <td><?php echo $result['customer_email']; ?></td>
                            </tr>  
                            <tr>
                                <td>Address</td>
                                <td>:</td>
                                <td><?php echo $result['customer_address']; ?></td>
                            </tr>  
                            <tr>
                                <td>Country</td>
                                <td>:</td>
                                <td><?php echo $result['country']; ?></td>
                            </tr>  
                            <tr>
                                <td>Phone</td>
                                <td>:</td>
                                <td><?php echo $result['customer_phone']; ?></td>
                            </tr>  
                            <tr>
                                <td></td>
                                <td colspan="2">
                                    <a href="editProfile.php">Edit Profile</a>
                                </td>
                               
                            </tr>  
                        </tbody>
                    </table> 
                </center>
            </form>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
</div>
<?php include 'inc/footer.php'; ?>