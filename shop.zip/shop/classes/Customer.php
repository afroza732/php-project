<?php

$file_path = realpath(dirname(__FILE__));
include_once ($file_path . '/../library/Database.php');
include_once ($file_path . '/../helper/Format.php');
?>
<?php

class Customer {

    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function customer_registration($data) {
        $customer_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_name']));
        $customer_city = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_city']));
        $zip_code = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['zip_code']));
        $customer_email = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_email']));
        $customer_address = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_address']));
        $country = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['country']));
        $customer_phone = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_phone']));
        $customer_password = mysqli_real_escape_string($this->db->link, $this->fm->validation(md5($data['customer_password'])));

        if ($customer_name == "" || $customer_city == "" || $zip_code == "" || $customer_email == "" || $customer_address == "" || $country == "" || $customer_phone == "" || $customer_password == "") {
            $Register = 'Field must not be empty !';
            return $Register;
        }
        $checkquery = "SELECT * FROM tbl_customer WHERE customer_email ='$customer_email' limit 1 ";
        $checkMail = $this->db->select($checkquery);
        if ($checkMail) {
            echo "<span style='color: red; font-size:15px;'>Email Already Exist !</span>";
        } else {
            $query = "INSERT INTO  tbl_customer(customer_name,customer_city,zip_code,customer_email,customer_address,country,customer_phone,customer_password) VALUES('$customer_name','$customer_city','$zip_code','$customer_email','$customer_address','$country','$customer_phone','$customer_password')";
            $inserted_rows = $this->db->insert($query);
            if ($inserted_rows) {
                $Register = 'Registration Successfull.   !';
                return $Register;
            } else {
                $Register = 'Registration not Successfull!';
                return $Register;
            }
        }
    }

    public function customer_login($data) {
        $customer_email = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_email']));
        $customer_password = mysqli_real_escape_string($this->db->link, $this->fm->validation(md5($data['customer_password'])));

        if (empty($customer_email) || empty($customer_password)) {
            $login = 'Field must not be empty !';
            return $login;
        } else {
            $query = "SELECT * FROM  tbl_customer WHERE customer_email ='$customer_email' AND customer_password = '$customer_password'";
            $result = $this->db->select($query);
            if ($result != false) {
                $value = $result->fetch_assoc();
                Session::set("login", true);
                Session::set("customer_id", $value['customer_id']);
                Session::set("customer_name", $value['customer_name']);
                header('Location: cart.php');
            } else {
                $message = "Email or Password are not matched!!!";
                return $message;
            }
        }
    }

    public function getCustomerInformation($id) {
        $query = "SELECT * FROM tbl_customer WHERE customer_id ='$id'";
        $result = $this->db->select($query);
        if ($result) {
            $result = $result->fetch_assoc();
            return $result;
        }
    }

    public function customer_profile_update($data,$id) {
        $customer_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_name']));
        $customer_city = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_city']));
        $zip_code = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['zip_code']));
        $customer_email = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_email']));
        $customer_address = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_address']));
        $country = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['country']));
        $customer_phone = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['customer_phone']));
        $customer_password = mysqli_real_escape_string($this->db->link, $this->fm->validation(md5($data['customer_password'])));

        if ($customer_name == "" || $customer_city == "" || $zip_code == "" || $customer_email == "" || $customer_address == "" || $country == "" || $customer_phone == "" || $customer_password == "") {
            $update = 'Field must not be empty !';
            return $update;
        } else {
            $query = "UPDATE tbl_customer SET customer_name ='$customer_name',customer_city = '$customer_city',zip_code = '$zip_code',customer_email = '$customer_email',customer_address = '$customer_address',country = '$country',customer_phone = '$customer_phone',customer_password = '$customer_password' WHERE customer_id ='$id'";
            $update_rows = $this->db->update($query);
            if ($update_rows) {
                $update = 'Profile Update Successfull.   !';
                return $update;
            } else {
                $update = 'Registration not Successfull!';
                return $update;
            }
        }
    }
    
    

}

?>