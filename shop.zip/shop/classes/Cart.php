<?php

$file_path = realpath(dirname(__FILE__));
include_once ($file_path . '/../library/Database.php');
include_once ($file_path . '/../helper/Format.php');
?>
<?php

class Cart {

    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function addToCart($data, $product_id) {
        $session_id = session_id();
        $product_id = mysqli_real_escape_string($this->db->link, $product_id);
        $quantity = mysqli_real_escape_string($this->db->link, $data['quantity']);

        $sql = "SELECT * FROM tbl_products WHERE product_id ='$product_id'";
        $result = $this->db->select($sql)->fetch_assoc();
        $product_name = $result['product_name'];
        $price = $result['price'];
        $image = $result['image'];

        $checkQuery = "SELECT * FROM tbl_cart WHERE product_id ='$product_id' AND session_id ='$session_id'";
        $product_check = $this->db->select($checkQuery);
        if ($product_check) {
            $message = "Product add already exist!";
            return $message;
        } else {
            $query = "INSERT INTO tbl_cart(session_id,product_id,product_name,price,quantity,image)VALUES('$session_id','$product_id','$product_name','$price','$quantity','$image')";
            $insert_query = $this->db->insert($query);
            if ($insert_query) {
                header("Location: cart.php");
            } else {
                header("Location: 404.php");
            }
        }
    }

    public function selectAllCartValue() {
        $session_id = session_id();
        $query = "SELECT * FROM tbl_cart WHERE session_id ='$session_id' ";
        $getCartValue = $this->db->select($query);
        if ($getCartValue) {
            return $getCartValue;
        }
    }

    public function quantity_update_info($cart_id, $quantity) {
        $cart_id = mysqli_real_escape_string($this->db->link, $cart_id);
        $quantity = mysqli_real_escape_string($this->db->link, $quantity);
        $query = "UPDATE tbl_cart SET quantity ='$quantity' WHERE cart_id ='$cart_id'";
        $quantity_update = $this->db->update($query);
        if ($quantity_update) {
            header("Location: cart.php");
        } else {
            $message = "Quantity not updated !!";
            return $message;
        }
    }

    public function cart_delete_info($id) {
        $query = "DELETE FROM tbl_cart WHERE cart_id ='$id' ";
        $cart_delete = $this->db->delete($query);
        if ($cart_delete) {
            $message = 'Cart Deleted succesfully !!';
            return $message;
        } else {
            $message = "Cart not deleted !!";
            return $message;
        }
    }

    public function getCartValue() {
        $session_id = session_id();
        $query = "SELECT * FROM tbl_cart WHERE session_id ='$session_id' ";
        $getCart = $this->db->select($query);
        return $getCart;
    }

    public function cartDeleteInfo() {
        $session_id = session_id();
        $query = "DELETE FROM tbl_cart WHERE session_id ='$session_id' ";
        $this->db->delete($query);
    }

    public function getOrderInformation($customer_id) {
        $session_id = session_id();
        $query = "SELECT * FROM tbl_cart WHERE session_id ='$session_id' ";
        $getProduct = $this->db->select($query);
        while ($result = $getProduct->fetch_assoc()) {
            $product_id = $result['product_id'];
            $product_name = $result['product_name'];
            $quantity = $result['quantity'];
            $price = $result['price'] * $quantity;
            $image = $result['image'];

            $query = "INSERT INTO tbl_order(customer_id,product_id,product_name,quantity,price,image)VALUES('$customer_id','$product_id','$product_name','$quantity','$price','$image')";
            $insert_query = $this->db->insert($query);
        }
    }

    public function select_price_info($customer_id) {
        $query = "SELECT price FROM tbl_order WHERE customer_id = '$customer_id'";
        $getPrice = $this->db->select($query);
        return $getPrice;
    }

    public function getOrderValue($customer_id) {
        $query = "SELECT * FROM tbl_order WHERE customer_id = '$customer_id' ORDER BY product_id DESC";
        $getOrder = $this->db->select($query);
        return $getOrder;
    }

    public function getOrderValues($customer_id) {
        $query = "SELECT * FROM tbl_order WHERE customer_id = '$customer_id'";
        $getOrder = $this->db->select($query);
        return $getOrder;
    }

    public function getOrderInfo() {
        $query = "SELECT * FROM tbl_order";
        $getOrder = $this->db->select($query);
        return $getOrder;
    }

    public function productShifted($id, $price, $date) {
        $id = mysqli_real_escape_string($this->db->link, $id);
        $price = mysqli_real_escape_string($this->db->link, $price);
        $date = mysqli_real_escape_string($this->db->link, $date);
        $query = "UPDATE tbl_order SET status ='1' WHERE customer_id ='$id' AND price = '$price' AND date ='$date'";
        $order_update = $this->db->update($query);
        if ($brand_update) {
            $message = "updated succesfully !!";
            return $message;
        } else {
            $message = "Not updated !!";
            return $message;
        }
    }

}

?>