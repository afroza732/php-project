<?php

$file_path = realpath(dirname(__FILE__));
include_once ($file_path . '/../library/Database.php');
include_once ($file_path . '/../helper/Format.php');
?>
<?php

class Product {

    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function product_all_save_info($data) {

        $product_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['product_name']));
        $category_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['category_id']));
        $brand_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['brand_id']));
        $body = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['body']));
        $price = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['price']));
        $type = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['type']));


        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_temp = $_FILES['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10) . '.' . $file_ext;
        $folder = "upload/" . $unique_image;


        if ($product_name == "" || $category_name == "" || $brand_name == "" || $body == "" || $price == "" || $file_name == "" || $type == "") {
            $message = 'Field must not be empty !';
            return $message;
        } elseif ($file_size > 1048567) {
            echo "<span class='error'>Image Size should be less then 1MB! </span>";
        } elseif (in_array($file_ext, $permited) === false) {
            echo "<span class='error'>You can upload only:-" . implode(', ', $permited) . "</span>";
        } else {
            move_uploaded_file($file_temp, $folder);
            $query = "INSERT INTO  tbl_products(product_name,category_id,brand_id,body,price,image,type) VALUES('$product_name','$category_name','$brand_name','$body','$price','$folder','$type')";
            $inserted_rows = $this->db->insert($query);
            if ($inserted_rows) {
                $message = 'Data Inserted Successfully.   !';
                return $message;
            } else {
                $message = 'Data Not Inserted !';
                return $message;
            }
        }
    }

    public function all_product_select_info() {
        $query = "SELECT p.*, c.category_name, b.brand_name FROM tbl_products as p, tbl_category as c, tbl_brand as b WHERE p.category_id =c.category_id AND p.brand_id = b.brand_id ORDER BY p.product_id DESC";
        $product_result = $this->db->select($query);
        if ($product_result) {
            return $product_result;
        } else {
            $message = 'Product Name Not Found !';
            return $message;
        }
    }

    public function select_product_info_by_id($product_id) {
        $query = "SELECT * FROM tbl_products WHERE product_id ='$product_id' ";
        $product_result = $this->db->select($query);
        if ($product_result) {
            $result = $product_result->fetch_assoc();
            return $result;
        } else {
            $message = 'Product Name Not Found !';
            return $message;
        }
    }

    public function product_update_info_by_id($data, $product_id) {
        $product_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['product_name']));
        $category_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['category_id']));
        $brand_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['brand_id']));
        $body = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['body']));
        $price = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['price']));
        $type = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['type']));


        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_temp = $_FILES['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10) . '.' . $file_ext;
        $folder = "upload/" . $unique_image;


        if ($product_name == "" || $category_name == "" || $brand_name == "" || $body == "" || $price == "" || $type == "") {
            $message = 'Field must not be empty !';
            return $message;
        }
        if (!empty($file_name)) {
            if ($file_size > 1048567) {
                echo "<span class='error'>Image Size should be less then 1MB! </span>";
            } elseif (in_array($file_ext, $permited) === false) {
                echo "<span class='error'>You can upload only:-" . implode(', ', $permited) . "</span>";
            } else {
                move_uploaded_file($file_temp, $folder);
                $query = "UPDATE tbl_products SET "
                        . "product_name ='$product_name',"
                        . "category_id='$category_name',"
                        . "brand_id='$brand_name',"
                        . "body='$body',"
                        . "price='$price',"
                        . "image='$folder' ,"
                        . "type='$type'"
                        . "WHERE product_id = '$product_id'";
                $updated_rows = $this->db->update($query);
                if ($updated_rows) {
                    $message = "Product updated Successfully.";
                    return $message;
                } else {
                    $message = "Product Not Successfully.";
                    return $message;
                }
            }
        } else {
            $query = "UPDATE tbl_products SET "
                    . "product_name ='$product_name',"
                    . "category_id='$category_name',"
                    . "brand_id='$brand_name',"
                    . "body='$body',"
                    . "price='$price',"
                    . "type='$type'"
                    . "WHERE product_id = '$product_id'";
            $updated_rows = $this->db->update($query);
            if ($updated_rows) {
                $message = "Product updated Successfully.";
                return $message;
            } else {
                $message = "Product Not Successfully.";
                return $message;
            }
        }
    }

    public function product_delete_info_by_id($id) {
        $sql = "SELECT * FROM tbl_products WHERE product_id = '$id'";
        $product_select = $this->db->select($sql);
        if ($product_select) {
            while ($result = $product_select->fetch_assoc()) {
                $del_link = $result['image'];
                unlink($del_link);
            }
        }
        $query = "DELETE FROM tbl_products WHERE product_id ='$id' ";
        $product_delete = $this->db->delete($query);
        if ($product_delete) {
            $message = 'Product  Deleted succesfully !!';
            return $message;
        } else {
            $message = "Product  not deleted !!";
            return $message;
        }
    }

    //front end query

    public function select_features_info() {
        $query = "SELECT * FROM tbl_products WHERE type ='0' ORDER BY product_id DESC limit 4 ";
        $product_features = $this->db->select($query);
        return $product_features;
    }

    public function select_all_new_product() {
        $query = "SELECT * FROM tbl_products WHERE type ='1' ORDER BY product_id ASC limit 4 ";
        $new_products = $this->db->select($query);
        return $new_products;
    }

    public function select_details_product($product_id) {
        $query = "SELECT p.*, c.category_name, b.brand_name FROM tbl_products as p, tbl_category as c, tbl_brand as b WHERE p.category_id =c.category_id AND p.brand_id = b.brand_id AND p.product_id = '$product_id'";
        $product_result = $this->db->select($query);
        if ($product_result) {
            $details_product = $product_result->fetch_assoc();
            return $details_product;
        } else {
            $message = 'Product Details Not Found !';
            return $message;
        }
    }

    public function view_iphone_info() {
        $query = "SELECT * FROM tbl_products WHERE brand_id ='2' ORDER BY product_id DESC limit 1 ";
        $getIphone = $this->db->select($query);
        return $getIphone;
    }

    public function view_samsung_info() {
        $query = "SELECT * FROM tbl_products WHERE brand_id ='3' ORDER BY product_id DESC limit 1 ";
        $getsamsung = $this->db->select($query);
        return $getsamsung;
    }

    public function view_acer_info() {
        $query = "SELECT * FROM tbl_products WHERE brand_id ='4' ORDER BY product_id DESC limit 1 ";
        $getAcer = $this->db->select($query);
        return $getAcer;
    }

    public function view_canon_info() {
        $query = "SELECT * FROM tbl_products WHERE brand_id ='5' ORDER BY product_id DESC limit 1 ";
        $getCanon = $this->db->select($query);
        return $getCanon;
    }

    public function viewProductInfoByCategory($category_id) {
        $query = "SELECT * FROM tbl_products WHERE category_id ='$category_id'";
        $getproductByCat = $this->db->select($query);
        return $getproductByCat;
    }

}
