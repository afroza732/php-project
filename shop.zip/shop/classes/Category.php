<?php $file_path = realpath(dirname(__FILE__));
 include_once ($file_path.'/../library/Database.php'); 
 include_once ($file_path.'/../helper/Format.php'); 
 
 ?>
<?php

class Category {

    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function category_save_info($data) {
        $category_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['category_name']));
        if (empty($category_name)) {
            $message = "Field Must not be Empty !!";
            return $message;
        } else {
            $query = "INSERT INTO tbl_category(category_name)VALUES('$category_name')";
            $category_insert = $this->db->insert($query);
            if ($category_insert) {
                $message = "Category inserted succesfully !!";
                return $message;
            } else {
                $message = "Category not inserted  !!";
                return $message;
            }
        }
    }

    public function all_category_select_info() {
        $query = "SELECT * FROM tbl_category order by  category_id desc ";
        $category_result = $this->db->select($query);
        if ($category_result) {
            return $category_result;
        } else {
            echo 'Category Not Found !';
        }
    }

    public function select_category_info_by_id($category_id) {
        $query = "SELECT * FROM tbl_category WHERE category_id ='$category_id' ";
        $category_result = $this->db->select($query);
        if ($category_result) {
            $result = $category_result->fetch_assoc();
            return $result;
        } else {
            echo 'Category Not Found !';
        }
    }

    public function category_update_info($data,$category_id) {
        $category_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['category_name']));
        if (empty($category_name)) {
            $message = "Field Must not be Empty !!";
            return $message;
        } else {
            $query = "UPDATE tbl_category SET category_name ='$category_name' WHERE category_id ='$category_id' ";
            $category_update = $this->db->update($query);
            if ($category_update) {
                $message = "Category updated succesfully !!";
                return $message;
            } else {
                $message = "Category not updated !!";
                return $message;
            }
        }
    }

    public function category_delete_info($id) {
        $query = "DELETE FROM tbl_category WHERE category_id ='$id' ";
        $category_delete = $this->db->delete($query);
        if ($category_delete) {
            $message = 'Category Deleted succesfully !!';
            return $message;
        } else {
            $message = "Category not deleted !!";
            return $message;
        }
    }

}

?>