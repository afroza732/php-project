<?php

$file_path = realpath(dirname(__FILE__));
include ($file_path . '/../library/Session.php');
Session::checkLogin();
include_once ($file_path . '/../library/Database.php');
include_once ($file_path . '/../helper/Format.php');
?>


<?php

class AdminLogin {

    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function login_admin($admin_username, $admin_password) {
        $admin_username = mysqli_real_escape_string($this->db->link, $this->fm->validation($_POST['admin_username']));
        $admin_password = mysqli_real_escape_string($this->db->link, $this->fm->validation(md5($_POST['admin_password'])));

        if (empty($admin_username) || empty($admin_password)) {
            $message = "Field Must not be Empty !!";
            return $message;
        } else {
            $query = "SELECT * FROM  tbl_admin WHERE admin_username ='$admin_username' AND admin_password = '$admin_password'";
            $result = $this->db->select($query);
            if ($result != false) {
                $value = $result->fetch_assoc();
                Session::set("login", true);
                $_SESSION['admin_username'] = $value['admin_username'];
                $_SESSION['admin_id'] = $value['admin_id'];
                header('Location: dashboard.php');
            } else {
                $message = "Username or Password not match!!!";
                return $message;
            }
        }
    }

   

}
?>