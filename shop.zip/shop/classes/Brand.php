<?php $file_path = realpath(dirname(__FILE__));
 include_once ($file_path.'/../library/Database.php'); 
 include_once ($file_path.'/../helper/Format.php'); 
 
 ?>
<?php

class Brand {

    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function brand_save_info($data) {
        $brand_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['brand_name']));
        if (empty($brand_name)) {
            $message = "Field Must not be Empty !!";
            return $message;
        } else {
            $query = "INSERT INTO tbl_brand(brand_name)VALUES('$brand_name')";
            $brand_insert = $this->db->insert($query);
            if ($brand_insert) {
                $message = "Brand Name inserted succesfully !!";
                return $message;
            } else {
                $message = "Brand Name not inserted  !!";
                return $message;
            }
        }
    }
    
    public function all_brand_select_info(){
        $query = "SELECT * FROM tbl_brand order by  brand_id desc ";
        $brand_result = $this->db->select($query);
        if ($brand_result) {
            return $brand_result;
        } else {
            $message  ='Brand Name Not Found !';
        }
    }
    
    public function select_brand_info_by_id($brand_id) {
        $query = "SELECT * FROM tbl_brand WHERE brand_id ='$brand_id' ";
        $brand_result = $this->db->select($query);
        if ($brand_result) {
            $result = $brand_result->fetch_assoc();
            return $result;
        } else {
             $message  ='Name Brand Not Found !';
        }
    }

    public function brand_update_info($data,$brand_id) {
        $brand_name = mysqli_real_escape_string($this->db->link, $this->fm->validation($data['brand_name']));
        if (empty($brand_name)) {
            $message = "Field Must not be Empty !!";
            return $message;
        } else {
             $query = "UPDATE tbl_brand SET brand_name ='$brand_name' WHERE brand_id ='$brand_id' ";
            $brand_update = $this->db->update($query);
            if ($brand_update) {
                $message = "Brand Name updated succesfully !!";
                return $message;
            } else {
                $message = "Brand Name not updated !!";
                return $message;
            }
        }
    }

    public function brand_delete_info($id) {
        $query = "DELETE FROM tbl_brand WHERE brand_id ='$id' ";
        $brand_delete = $this->db->delete($query);
        if ($brand_delete) {
            $message = 'Brand Name Deleted succesfully !!';
            return $message;
        } else {
            $message = "Brand Name not deleted !!";
            return $message;
        }
    }

}

?>