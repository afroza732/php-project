<!DOCTYPE html>
<html>
<head>
    <base href="http://localhost/web/"
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title> Admin</title>
    <link rel="stylesheet" type="text/css" href="assets/admin/css/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="assets/admin/css/text.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="assets/admin/css/grid.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="assets/admin/css/layout.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="assets/admin/css/nav.css" media="screen" />
    <link href="assets/admin/css/table/demo_page.css" rel="stylesheet" type="text/css" />
    <!-- BEGIN: load jquery -->
    <script src="assets/admin/js/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script type="assets/admin/text/javascript" src="js/jquery-ui/jquery.ui.core.min.js"></script>
    <script src="assets/admin/js/jquery-ui/jquery.ui.widget.min.js" type="text/javascript"></script>
    <script src="assets/admin/js/jquery-ui/jquery.ui.accordion.min.js" type="text/javascript"></script>
    <script src="assets/admin/js/jquery-ui/jquery.effects.core.min.js" type="text/javascript"></script>
    <script src="assets/admin/js/jquery-ui/jquery.effects.slide.min.js" type="text/javascript"></script>
    <script src="assets/admin/js/jquery-ui/jquery.ui.mouse.min.js" type="text/javascript"></script>
    <script src="assets/admin/js/jquery-ui/jquery.ui.sortable.min.js" type="text/javascript"></script>
    <script src="assets/admin/js/table/jquery.dataTables.min.js" type="text/javascript"></script>
    <!-- END: load jquery -->
    <script type="text/javascript" src="assets/admin/js/table/table.js"></script>
    <script src="assets/admin/js/setup.js" type="text/javascript"></script>
	 <script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>

</head>