
<style>
    /*dEFULT*/
    input[type="submit"] {
        background: #197a1f none repeat scroll 0 0;
    }
    input[type="submit"]:hover{background:#197a1f;color:#000;}

    .headersection {
        background: #197a1f none repeat scroll 0 0;
    }

    .icon a {
        background: #197a1f none repeat scroll 0 0;
        border-radius: 1px solid #197a1f;

    }
    .icon a:hover{background:#fff;color:#333}

    .searchbtn input[type="text"] {
        border: 1px solid #19501f ;
        background: #197a1f ;
        height: 30px;
        color:#fff;
    }
    .searchbtn input[type="submit"] {
        border: 1px solid #19501f;
    }
    .searchbtn input[type="submit"]:hover{
        background: #197a1f none repeat scroll 0 0;
        border: 1px solid #19501f;
        color:#fff;
    }


    .navsection {
        background: none repeat scroll 0 0 #198d1f;
        border: 1px solid #198d1f;

    }
    .navsection ul li {
        border-left: #19d91f;
        border-right: 1px solid #198d1f;

    }


    .slidersection {}
    .contentsection {
        background: #ffffff none repeat scroll 0 0;
        border: 1px solid #ca932f;
        padding: 15px;
    }
    .maincontent {
        background: #a4f993 none repeat scroll 0 0;
        border: 1px solid #198d1f;
    }

    .about img {
        background: #fff none repeat scroll 0 0;
        border: 1px solid #b7801c;
        float: left;
        height: 190px;
        margin-right: 10px;
        padding: 5px;
        width: 300px;
    }


    .pagination a{
        background: #e6afb4 none repeat scroll 0 0; 
        color: #fff;

    }
    .pagination a:hover{
        background: #e6afb4 none repeat scroll 0 0;    
    }
  .samepost h2 a {
    color: #000;

}

.contentsection {
    background: #66ea48 none repeat scroll 0 0;
}

.sidebar {
    background: #A4F993 none repeat scroll 0 0;
}
.samesidebar h2 {
    background: #197A1F none repeat scroll 0 0;
}
.footersection {
    background: #197A1F;

}
   </style>