<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "blog_db");
define("TITLE", "blog");
define("KEYWORDS", "PHP tutorial,JAVA tutorial,C#");
define("DESCRIPTION", "Website title here");

