<?php
echo metaphone(“world”);
?>
