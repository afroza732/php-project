<?php

class functions {
    
    public function add($a,$b){
        echo "Summation is : ".($a+$b).'</br>';
    }
    public function sub($a,$b){
        echo "Substraction is : ".($a-$b).'</br>';
    }
    public function mul($a,$b){
        echo "Multiplication is : ".($a*$b).'</br>';
    }
    public function div($a,$b){
        echo "Division is : ".($a/$b).'</br>';
    }
}
