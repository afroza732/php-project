</section>

  <footer class="footeroption">
  <h2>www.trainingWithLiveProject.com</h2>
  </footer>

</body>
</html>